#pragma once

#include <ntifs.h>
#include <ntdef.h>
#include <ntddk.h>
#include <wdm.h>
#include <ntstatus.h>
#include <ntimage.h>
#include <ntstrsafe.h>
#include <intrin.h>
#include <intsafe.h>