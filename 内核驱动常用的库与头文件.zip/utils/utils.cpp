#include "utils.h"

Utils* Utils::m_Instance;

Utils* Utils::fn_get_instance() 
{
    if (m_Instance == 0) {

        m_Instance = (Utils*)ExAllocatePoolWithTag(NonPagedPool, sizeof(Utils), 'util');

        //分配蹦床内存 清空HookInfo数组
        m_Instance->m_tramp_line = (uint8_t*)ExAllocatePoolWithTag(NonPagedPool, PAGE_SIZE * 10, 'util');
        m_Instance->m_tramp_line_used = 0;
        m_Instance->m_count = 0;
        if (m_Instance == 0 || m_Instance->m_tramp_line==0) {
            
            DbgPrintEx(77,0,"[+]failed to alloc instance\r\n");
            return 0;
        }

        RtlSecureZeroMemory(m_Instance->m_hook_info_table, MAX_HOOK_COUNT * sizeof(HOOK_INFO));
        //后面是自己补的
    }
    
    return m_Instance;
}

uint32_t Utils::fn_get_os_build_number() {
    RTL_OSVERSIONINFOW version = { 0 };
    version.dwOSVersionInfoSize = sizeof(version);
    RtlGetVersion(&version);
    return version.dwBuildNumber;
}

uint64_t Utils::fn_get_module_address(const char* name, unsigned long* size) {
    ULONG length = 0;
    ZwQuerySystemInformation(11, NULL, 0, &length); // SystemModuleInformation = 11

    if (length == 0) return 0;

    PSYSTEM_MODULE_INFORMATION system_modules = (PSYSTEM_MODULE_INFORMATION)ExAllocatePoolWithTag(NonPagedPool, length, POOL_TAG);
    if (!system_modules) return 0;

    NTSTATUS status = ZwQuerySystemInformation(11, system_modules, length, 0);
    uint64_t result = 0;

    if (NT_SUCCESS(status)) {
        for (ULONG i = 0; i < system_modules->ulModuleCount; i++) {
            PSYSTEM_MODULE mod = &system_modules->Modules[i];
            // Simple strstr or exact match check
            if (strstr(mod->ImageName, name)) {
                result = (uint64_t)mod->Base;
                if (size) *size = mod->Size;
                break;
            }
        }
    }

    ExFreePoolWithTag(system_modules, POOL_TAG);
    return result;
}

bool Utils::fn_pattern_check(const char* data, const char* pattern, const char* mask) {
    size_t len = strlen(mask);
    for (size_t i = 0; i < len; i++) {
        if (mask[i] == '?') continue;
        if (data[i] != pattern[i]) return false;
    }
    return true;
}

uint64_t Utils::fn_find_pattern(uint64_t addr, unsigned long size, const char* pattern, const char* mask) {
    for (unsigned long i = 0; i < size; i++) {
        if (fn_pattern_check((const char*)(addr + i), pattern, mask)) {
            return addr + i;
        }
    }
    return 0;
}

uint64_t Utils::fn_get_image_address(uint64_t addr, const char* name, unsigned long size) {
    // This function typically parses PE headers to find sections, 
    // but based on the PDF context, it seems to act as a wrapper to find_pattern 
    // or simply returns the module base if no pattern is needed.
    // Given the arguments, it likely scans a specific module.
    // Implementation placeholder based on typical usage:
    return 0; 
}

void Utils::fn_logger(const char* log_str, bool is_err, long err_code)
{
    if (is_err) DbgPrintEx(77, 0, "[utils.cpp]err:%s err_code :%x\r\n", log_str, err_code);
    else DbgPrintEx(77, 0, "[utils.cpp]info: %s\r\n", log_str);
}


// （对应原代码片段2）
KIRQL Utils::fn_wp_bit_off()
{
    ////关闭CR0
    auto irql = KeRaiseIrqlToDpcLevel();//关闭线程切换
    UINT64 Cr0 = __readcr0();
    Cr0 &= 0xfffffffffffeffff;
    __writecr0(Cr0);
    _disable();
    return irql;
}


// （对应原代码片段3）
void Utils::fn_wp_bit_on(KIRQL irql)
{
    ////开启CR0
    UINT64 Cr0 = __readcr0();
    Cr0 |= 0x10000;
    _enable();
    __writecr0(Cr0);
    KeLowerIrql(irql);
}

void* Utils::fn_tramp_line_init(void* ret_address, uint64_t break_bytes_count, unsigned char* break_bytes)
{
    const ULONG TrampLineBreakBytes = 20;

    unsigned char TrampLineCode[TrampLineBreakBytes] = { //push xxx mov ret 不影响任何寄存器
    0x6A, 0x00, 0x3E, 0xC7, 0x04, 0x24, 0x00, 0x00, 0x00, 0x00,
    0x3E, 0xC7, 0x44, 0x24, 0x04, 0x00, 0x00, 0x00, 0x00, 0xC3
    };

    //复制绝对跳转
    *((PUINT32)&TrampLineCode[6]) = (UINT32)(((uint64_t)ret_address + break_bytes_count) & 0xFFFFFFFF);
    *((PUINT32)&TrampLineCode[15]) = (UINT32)((((uint64_t)ret_address + break_bytes_count) >> 32) & 0xFFFFFFFF);

    auto& used = m_Instance->m_tramp_line_used;
    auto& tramp_line_base = m_Instance->m_tramp_line;

    //复制原先毁掉的字节
    RtlCopyMemory(tramp_line_base + used, break_bytes, break_bytes_count);
    RtlCopyMemory(tramp_line_base + used + break_bytes_count, TrampLineCode, sizeof(TrampLineCode));

    auto ret = tramp_line_base + used;
    used += TrampLineBreakBytes + break_bytes_count;

    return ret;
}

// Internal helper to find the Object Type Index Table
uintptr_t* Utils::fn_get_index_table()
{
    RTL_OSVERSIONINFOW version = { 0 };
    RtlGetVersion(&version);
    LARGE_INTEGER in = { 0 };
    PUCHAR typeAddr = 0;

    UNICODE_STRING funcName = { 0 };
    RtlInitUnicodeString(&funcName, L"ObGetObjectType");
    PUCHAR MyObGetObjectType = (PUCHAR)MmGetSystemRoutineAddress(&funcName);

    if (!MyObGetObjectType) return NULL;

    if (version.dwMajorVersion <= 6)
    {
        typeAddr = (PUCHAR)MyObGetObjectType + 7;
    }
    else
    {
        typeAddr = (PUCHAR)MyObGetObjectType + 0x1F;
    }

    if (!typeAddr) return NULL;

    in.QuadPart = (ULONG64)(typeAddr + 4);
    in.LowPart += *((PULONG)typeAddr);
    return (uintptr_t*)in.QuadPart;
}

POBJECT_TYPE Utils::fn_get_type_by_name(wchar_t* name)
{
    PULONG64 table = (PULONG64)fn_get_index_table(); // 通过导出函数ObGetObjectType获取对象类型表(win10导出的ObTypeIndexTable win7没)
    if (!table) return NULL;

    UNICODE_STRING tName = { 0 };
    RtlInitUnicodeString(&tName, name);
    PMOBJECT_TYPE retObjType = NULL;

    for (int i = 0; i < 0xFF; i++)
    {
        PMOBJECT_TYPE type = (PMOBJECT_TYPE)table[i];
        if (type && MmIsAddressValid(type))
        {
            if (RtlCompareUnicodeString(&type->Name, &tName, TRUE) == 0)
            {
                retObjType = type;
                break;
            }
        }
    }

    return (POBJECT_TYPE)retObjType;
}

bool Utils::fn_hook_by_address(void* ori_func_addr, void* target_func_addr) {
    if (!ori_func_addr || !target_func_addr) return false;
    if (m_count >= MAX_HOOK_COUNT) return false;

    // 1. Calculate length of instructions to overwrite (need at least 14 bytes for long JMP)
    hde64s hs;
    unsigned int len = 0;
    unsigned char* p = (unsigned char*)ori_func_addr;
    
    while (len < 14) {
        unsigned int instr_len = hde64_disasm(p + len, &hs);
        if (instr_len == 0) return false; // Error decoding
        len += instr_len;
    }

    // 2. Prepare Trampoline
    // Structure: [Stolen Bytes] + [JMP back to ori_func + len]
    uint64_t tramp_addr = (uint64_t)(m_tramp_line + m_tramp_line_used);
    
    // Copy stolen bytes
    RtlCopyMemory((void*)tramp_addr, ori_func_addr, len);
    
    // Create JMP back
    // JMP [RIP+0] -> FF 25 00 00 00 00
    // Address (8 bytes)
    unsigned char jmp_stub[] = { 0xFF, 0x25, 0x00, 0x00, 0x00, 0x00 };
    uint64_t return_addr = (uint64_t)ori_func_addr + len;

    RtlCopyMemory((void*)(tramp_addr + len), jmp_stub, sizeof(jmp_stub));
    *(uint64_t*)(tramp_addr + len + 6) = return_addr;

    // Update trampoline usage
    m_tramp_line_used += (len + 14);

    // 3. Save Hook Info
    m_hook_info_table[m_count].ori_hook_addr = ori_func_addr;
    m_hook_info_table[m_count].target_hook_addr = target_func_addr;
    RtlCopyMemory(m_hook_info_table[m_count].old_bytes, ori_func_addr, 14); // Save enough to restore, simplified
    m_count++;

    // 4. Perform Hook (Overwrite ori_func with JMP to target_func)
    fn_wp_bit_off();
    
    RtlCopyMemory((void*)ori_func_addr, jmp_stub, sizeof(jmp_stub));
    *(uint64_t*)((uint64_t)ori_func_addr + 6) = (uint64_t)target_func_addr;

    // NOP remaining bytes if the stolen length was > 14
    for (unsigned int i = 14; i < len; i++) {
        *(unsigned char*)((uint64_t)ori_func_addr + i) = 0x90;
    }

    fn_wp_bit_on();

    return true;
}

bool Utils::fn_remove_hook_by_address(void* ori_func_addr) {
    for (int i = 0; i < MAX_HOOK_COUNT; i++) {
        if (m_hook_info_table[i].ori_hook_addr == ori_func_addr) {
            
            // Restore original bytes
            fn_wp_bit_off();
            
            // Note: We need to know exact length to restore fully, 
            // but usually restoring 14 bytes (the JMP) + whatever was NOP'd is vital.
            // For this implementation, we assume restoring the 14 bytes we corrupted is enough 
            // provided the rest were just NOPs or we saved the full length. 
            // A robust implementation would save the 'len' in HOOK_INFO.
            RtlCopyMemory(ori_func_addr, m_hook_info_table[i].old_bytes, 14);
            
            fn_wp_bit_on();

            m_hook_info_table[i].ori_hook_addr = 0;
            m_hook_info_table[i].target_hook_addr = 0;
            return true;
        }
    }
    return false;
}
