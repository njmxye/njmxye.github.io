#include "utils.h"

Utils* Utils::m_Instance = NULL;

Utils* Utils::fn_get_instance() {
    if (m_Instance == NULL) {
        m_Instance = (Utils*)ExAllocatePoolWithTag(NonPagedPool, sizeof(Utils), POOL_TAG); [cite: 141]
        
        // Allocate trampoline memory and clear hook info
        if (m_Instance) {
            RtlSecureZeroMemory(m_Instance, sizeof(Utils));
            
            // Allocate 10 pages for trampoline code
            m_Instance->m_tramp_line = (uint8_t*)ExAllocatePoolWithTag(NonPagedPool, PAGE_SIZE * 10, POOL_TAG); [cite: 143]
            m_Instance->m_tramp_line_used = 0;
            m_Instance->m_count = 0;

            if (m_Instance->m_tramp_line == NULL) {
                DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, " + failed to alloc instance\r\n"); [cite: 146]
                ExFreePoolWithTag(m_Instance, POOL_TAG);
                m_Instance = NULL;
                return NULL;
            }

            RtlSecureZeroMemory(m_Instance->m_hook_info_table, MAX_HOOK_COUNT * sizeof(HOOK_INFO)); [cite: 147]
        }
    }
    return m_Instance;
}

uint32_t Utils::fn_get_os_build_number() {
    RTL_OSVERSIONINFOW version = { 0 };
    version.dwOSVersionInfoSize = sizeof(version);
    RtlGetVersion(&version);
    return version.dwBuildNumber;
}

uint64_t Utils::fn_get_module_address(const char* name, unsigned long* size) {
    ULONG length = 0;
    ZwQuerySystemInformation(11, NULL, 0, &length); [cite: 149]
    
    if (length == 0) return 0;

    PSYSTEM_MODULE_INFORMATION system_modules = (PSYSTEM_MODULE_INFORMATION)ExAllocatePoolWithTag(NonPagedPool, length, POOL_TAG); [cite: 151]
    if (!system_modules) return 0;

    NTSTATUS status = ZwQuerySystemInformation(11, system_modules, length, 0); [cite: 175]
    uint64_t result = 0;

    if (NT_SUCCESS(status)) {
        for (ULONG i = 0; i < system_modules->ulModuleCount; i++) {
            PSYSTEM_MODULE mod = &system_modules->Modules[i];
            
            // PDF used 'atestz', likely strstr or similar check
            if (strstr(mod->ImageName, name)) { [cite: 178]
                result = (uint64_t)mod->Base; [cite: 179]
                if (size) *size = mod->Size; [cite: 180]
                break;
            }
        }
    }

    ExFreePoolWithTag(system_modules, POOL_TAG);
    return result;
}

bool Utils::fn_pattern_check(const char* data, const char* pattern, const char* mask) {
    size_t len = strlen(mask);
    for (size_t i = 0; i < len; i++) {
        if (mask[i] == '?') continue;
        if (data[i] != pattern[i]) return false;
    }
    return true;
}

uint64_t Utils::fn_find_pattern(uint64_t addr, unsigned long size, const char* pattern, const char* mask) {
    for (unsigned long i = 0; i < size; i++) {
        if (fn_pattern_check((const char*)(addr + i), pattern, mask)) {
            return addr + i;
        }
    }
    return 0;
}

uint64_t Utils::fn_find_pattern_image(uint64_t addr, const char* pattern, const char* mask, const char* name) {
    unsigned long size = 0;
    uint64_t base = fn_get_module_address(name, &size);
    if (!base) return 0;
    return fn_find_pattern(base, size, pattern, mask);
}

// Write protection control (CR0)
void Utils::fn_wp_bit_off() {
    CR0 cr0;
    cr0.all = __readcr0();
    cr0.write_protect = 0;
    __writecr0(cr0.all);
    _disable();
}

void Utils::fn_wp_bit_on() {
    _enable();
    CR0 cr0;
    cr0.all = __readcr0();
    cr0.write_protect = 1;
    __writecr0(cr0.all);
}

bool Utils::fn_hook_by_address(void* ori_func_addr, void* target_func_addr) {
    if (!ori_func_addr || !target_func_addr) return false;
    if (m_count >= MAX_HOOK_COUNT) return false;

    // Disassemble to determine how many bytes to steal (need >= 14 for x64 JMP)
    hde64s hs;
    unsigned int len = 0;
    unsigned char* p = (unsigned char*)ori_func_addr;
    
    while (len < 14) {
        unsigned int instr_len = hde64_disasm(p + len, &hs);
        if (instr_len == 0) return false;
        len += instr_len;
    }

    // Allocate space in trampoline
    uint64_t tramp_addr = (uint64_t)(m_tramp_line + m_tramp_line_used);
    
    // Copy stolen bytes to trampoline [cite: 287]
    RtlCopyMemory((void*)tramp_addr, ori_func_addr, len);
    
    // Append JMP back to original function + len [cite: 288]
    // FF 25 00 00 00 00 [Address]
    unsigned char jmp_stub[] = { 0xFF, 0x25, 0x00, 0x00, 0x00, 0x00 };
    uint64_t return_addr = (uint64_t)ori_func_addr + len;

    RtlCopyMemory((void*)(tramp_addr + len), jmp_stub, sizeof(jmp_stub));
    *(uint64_t*)(tramp_addr + len + 6) = return_addr;

    m_tramp_line_used += (len + 14);

    // Save Hook Info
    m_hook_info_table[m_count].ori_hook_addr = ori_func_addr;
    m_hook_info_table[m_count].target_hook_addr = target_func_addr;
    RtlCopyMemory(m_hook_info_table[m_count].old_bytes, ori_func_addr, 14);
    m_count++;

    // Write the hook
    fn_wp_bit_off();
    
    RtlCopyMemory((void*)ori_func_addr, jmp_stub, sizeof(jmp_stub));
    *(uint64_t*)((uint64_t)ori_func_addr + 6) = (uint64_t)target_func_addr;
    
    // NOP remaining stolen bytes
    for (unsigned int i = 14; i < len; i++) {
        *(unsigned char*)((uint64_t)ori_func_addr + i) = 0x90;
    }

    fn_wp_bit_on();

    return true;
}

bool Utils::fn_remove_hook_by_address(void* ori_func_addr) {
    for (int i = 0; i < MAX_HOOK_COUNT; i++) {
        if (m_hook_info_table[i].ori_hook_addr == ori_func_addr) {
            fn_wp_bit_off();
            RtlCopyMemory(ori_func_addr, m_hook_info_table[i].old_bytes, 14);
            fn_wp_bit_on();
            
            m_hook_info_table[i].ori_hook_addr = 0;
            return true;
        }
    }
    return false;
}

POBJECT_TYPE Utils::fn_get_type_by_name(wchar_t* name) {
    // Get the ObTypeIndexTable via helper
    PULONG64 table = (PULONG64)fn_get_index_table(); [cite: 215]
    if (!table) return NULL;

    UNICODE_STRING tName;
    RtlInitUnicodeString(&tName, name); [cite: 221]

    POBJECT_TYPE retObjType = NULL;

    // Loop through the table (index 0 to 0xFF implied by OS limits usually)
    for (int i = 0; i < 0xFF; i++) { [cite: 223]
        POBJECT_TYPE type = (POBJECT_TYPE)table[i]; [cite: 226]
        
        if (type && MmIsAddressValid(type)) { [cite: 227]
            if (RtlCompareUnicodeString(&type->Name, &tName, TRUE) == 0) { [cite: 237]
                retObjType = type; [cite: 238]
                break;
            }
        }
    }
    return retObjType;
}

// Helper to resolve ObGetObjectType logic and find the Type Index Table
uintptr_t* Utils::fn_get_index_table() {
    RTL_OSVERSIONINFOW version = { 0 };
    version.dwOSVersionInfoSize = sizeof(version);
    RtlGetVersion(&version); [cite: 306]

    LARGE_INTEGER in = { 0 };
    PUCHAR typeAddr = 0;
    
    UNICODE_STRING funcName;
    RtlInitUnicodeString(&funcName, L"ObGetObjectType"); [cite: 314]
    
    PUCHAR MyObGetObjectType = (PUCHAR)MmGetSystemRoutineAddress(&funcName); [cite: 316]
    if (!MyObGetObjectType) return NULL; [cite: 320]

    // Determine offset based on OS version
    if (version.dwMajorVersion <= 6) { [cite: 323]
        // Win7 Logic: Instruction at offset + 7
        typeAddr = ((PUCHAR)MyObGetObjectType + 7); [cite: 326]
    }
    else {
        // Win10/11 Logic: Instruction at offset + 0x1F
        typeAddr = ((PUCHAR)MyObGetObjectType + 0x1F); [cite: 335]
    }

    if (!typeAddr) return NULL;

    // RIP Relative resolution:
    // Target = (Instruction_End) + Offset_Value
    // Here, typeAddr points to the 32-bit Offset field inside the instruction.
    // So Instruction_End is (typeAddr + 4).
    in.QuadPart = (ULONG64)(typeAddr + 4); [cite: 345]
    
    // Add the signed 32-bit offset value found at typeAddr
    in.LowPart += (*(PULONG)typeAddr); [cite: 346]
    
    return (uintptr_t*)in.QuadPart; [cite: 347]
}