const DictationGrader = (() => {
  const separators = /[，,、；;。！？!?：:/|]+/u;
  const decoration = /[\s()（）[\]【】“”‘’"']/gu;
  const literalBeforeCausative = new Set(["天", "大", "出", "指", "驱", "致", "唆", "促", "差", "即", "假", "奉", "主", "行"]);
  const literalAfterCausative = new Set(["用", "命", "者", "节", "劲", "唤", "然", "臣", "馆"]);
  const boundPrefixes = new Set([
    "不", "没", "无", "未", "非", "别", "勿", "莫",
    "无法", "不能", "不可", "不会", "不是", "没有", "并不", "并非",
    "不得", "不必", "不再", "不曾", "毫不", "毫无", "绝不", "尚未", "难以",
    "使", "让", "令", "令人", "准许", "允许", "禁止", "可以", "能够",
    "必须", "需要", "应当", "应该", "成为", "作为", "关于", "对于",
  ]);
  let segmenter = null;
  try {
    if (typeof Intl !== "undefined" && typeof Intl.Segmenter === "function") {
      segmenter = new Intl.Segmenter("zh-CN", { granularity: "word" });
    }
  } catch {}

  function splitGloss(text) {
    const normalized = String(text ?? "").normalize("NFKC").replace(decoration, "");
    const core = normalized.replace(/使(?=\p{Script=Han})/gu, (marker, offset) => {
      if (literalBeforeCausative.has(normalized[offset - 1]) || literalAfterCausative.has(normalized[offset + 1])) return marker;
      return "";
    });
    return core.split(separators).filter(Boolean);
  }

  function coreParts(text) {
    if (!segmenter) return [text];
    const parts = Array.from(segmenter.segment(text), (part) => part.segment)
      .filter((part, index, segments) => part !== "令人" || !/\p{Script=Han}/u.test(segments[index + 1] || ""));
    return parts.map((part, index) => {
      if ((part === "的" || part === "地") && index > 0 && /\p{Script=Han}/u.test(parts[index - 1])) return "";
      return part;
    });
  }

  function coreTerms(parts) {
    const terms = [];
    let prefix = "";
    parts.forEach((part) => {
      if (!part) {
        if (prefix) {
          if (terms.length) terms[terms.length - 1] += prefix;
          else terms.push(prefix);
          prefix = "";
        }
      } else if (boundPrefixes.has(part) || /^\p{Script=Han}$/u.test(part)) {
        prefix += part;
      } else {
        terms.push(prefix + part);
        prefix = "";
      }
    });
    if (prefix) {
      if (terms.length) terms[terms.length - 1] += prefix;
      else terms.push(prefix);
    }
    return terms;
  }

  function matchesTerms(text, terms) {
    const counts = new Map();
    terms.forEach((term) => counts.set(term, (counts.get(term) || 0) + 1));
    const distinctTerms = [...counts.keys()].sort((first, second) => second.length - first.length);
    const remaining = distinctTerms.map((term) => counts.get(term));
    const failedStates = new Set();

    function matchAt(offset) {
      if (offset === text.length) return remaining.every((count) => count === 0);
      const key = `${offset}:${remaining.join(",")}`;
      if (failedStates.has(key)) return false;
      for (let index = 0; index < distinctTerms.length; index += 1) {
        const term = distinctTerms[index];
        if (!remaining[index] || !text.startsWith(term, offset)) continue;
        remaining[index] -= 1;
        const matched = matchAt(offset + term.length);
        remaining[index] += 1;
        if (matched) return true;
      }
      failedStates.add(key);
      return false;
    }

    return matchAt(0);
  }

  function matches(typed, expected) {
    const typedText = String(typed ?? "").trim();
    const expectedText = String(expected ?? "").trim();
    if (!typedText || !expectedText) return false;
    if (typedText === expectedText) return true;
    const typedParts = splitGloss(typedText).map(coreParts);
    const expectedParts = splitGloss(expectedText).map(coreParts);
    const typedCore = typedParts.flat().join("");
    const expectedCore = expectedParts.flat().join("");
    if (!typedCore || !expectedCore || typedCore.length !== expectedCore.length) return false;
    if (typedCore === expectedCore) return true;
    const terms = expectedParts.flatMap(coreTerms);
    if (expectedCore.length > 256 || terms.length > 32) return false;
    return matchesTerms(typedCore, terms);
  }

  return { matches };
})();

if (typeof module !== "undefined" && module.exports) module.exports = DictationGrader;
