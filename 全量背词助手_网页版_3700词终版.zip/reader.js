(function () {
  "use strict";
  const library = window.READING_LIBRARY || [window.READING_INLINE].filter(Boolean);
  let data = library[0];
  const core = window.ReaderCore;
  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = "gaokao-word-app-reader-v2";
  const view = $("reader-scroll");
  const article = $("reader-article");
  const bubble = $("reader-bubble");
  let preferences = core.normalizePreferences({}, data?.paragraphs.length);
  let viewedMarks = new Set();
  let rendered = false;
  let active = false;
  let selected = null;
  let paragraphs = [];
  let saveTimer;
  let scrollFrame;
  let restoreFrame;
  let articleStates = {};
  let readingRounds = {};
  let paragraphCompletions = {};
  let finishedParagraphs = new Set();

  function normalizeParagraphs(raw) {
    const total = data.paragraphGroups ? data.paragraphGroups.length - 1 : data.paragraphs.length;
    return new Set(Array.isArray(raw) ? raw.filter((n) => Number.isInteger(n) && n >= 0 && n < total) : []);
  }

  function readStore(key) {
    try { return JSON.parse(localStorage.getItem(key)); } catch (_) { return null; }
  }
  try {
    const saved = readStore(STORAGE_KEY);
    const legacy = readStore("gaokao-word-app-reader-v1");
    const state = core.normalizeLibraryState(saved, library, legacy);
    data = library.find((item) => item.id === state.articleId);
    articleStates = state.articles;
    preferences = core.normalizePreferences({ ...state.preferences, ...articleStates[data.id] }, data.paragraphs.length);
    viewedMarks = new Set(articleStates[data.id].viewedMarks);
    for (const item of library) readingRounds[item.id] = core.normalizeReadingRounds(saved?.readingRounds?.[item.id]);
    paragraphCompletions = saved?.paragraphCompletions && typeof saved.paragraphCompletions === "object" && !Array.isArray(saved.paragraphCompletions) ? saved.paragraphCompletions : {};
    finishedParagraphs = normalizeParagraphs(paragraphCompletions[data.id]);
  } catch (_) { /* A damaged/unavailable reader store must not affect training. */ }

  function persist() {
    try {
      if (rounds().current && !rounds().current.completedAt) Object.assign(rounds().current, lookupSummary());
      articleStates[data.id] = { paragraph: preferences.paragraph, offset: preferences.offset, viewedMarks: [...viewedMarks] };
      paragraphCompletions[data.id] = [...finishedParagraphs];
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ articleId: data.id, preferences, articles: articleStates, readingRounds, paragraphCompletions }));
      $("reader-save-status").textContent = "阅读位置已保存";
      updateRoundUI();
      renderRecords();
    } catch (_) {
      $("reader-save-status").textContent = "此环境无法保存阅读位置";
    }
  }

  function rounds() {
    if (!readingRounds[data.id]) readingRounds[data.id] = core.normalizeReadingRounds(null);
    return readingRounds[data.id];
  }

  function lookupSummary() {
    const words = new Set([...viewedMarks].map((key) => {
      const [pi, mi] = key.split(":").map(Number);
      return data.paragraphs[pi]?.marks[mi]?.[2];
    }).filter(Boolean));
    return { lookupCount: viewedMarks.size, uniqueWords: words.size, paragraphCount: finishedParagraphs.size };
  }

  function updateRoundUI() {
    const record = rounds();
    const completed = record.history.filter((round) => round.completedAt).length + (record.current?.completedAt ? 1 : 0);
    $("reader-round-note").textContent = `第 ${record.history.length + 1} 轮 · 已读 ${completed} 遍`;
    const button = $("reader-complete-round");
    if (button) {
      button.disabled = Boolean(record.current?.completedAt);
      button.textContent = record.current?.completedAt ? `本轮已完成 · 累计 ${completed} 遍` : "本轮读完";
    }
  }

  function renderRecords() {
    if (!$("reading-round-history")) return;
    const record = rounds();
    const all = [...record.history, ...(record.current ? [{ ...record.current, ...(!record.current.completedAt ? lookupSummary() : {}) }] : [])];
    const complete = all.filter((round) => round.completedAt);
    $("reading-completed-total").textContent = `完整读完 ${complete.length} 遍`;
    const current = record.current;
    $("reading-current-summary").textContent = current
      ? `第 ${record.history.length + 1} 轮${current.completedAt ? "已完成" : "进行中"} · 已读 ${finishedParagraphs.size} 段 · 本轮查阅 ${lookupSummary().lookupCount} 处（${lookupSummary().uniqueWords} 个词条）`
      : "尚未开始新轮次；已有查词标记会保留到你开启新一轮。";
    const previous = complete[complete.length - 2];
    const latest = complete[complete.length - 1];
    const change = latest && previous ? latest.lookupCount - previous.lookupCount : null;
    $("reading-round-feedback").textContent = change === null
      ? (latest ? "已完成第一遍。下一轮可对比查词数量。" : "读完后在文末点“本轮读完”，记下完整一遍。")
      : `最近一遍查阅 ${latest.lookupCount} 处，${change === 0 ? "与上一遍相同" : `比上一遍${change < 0 ? "少" : "多"} ${Math.abs(change)} 处`}。`;
    $("reading-round-history").replaceChildren(...all.map((round, index) => {
      const li = document.createElement("li");
      const date = new Date(round.completedAt || round.endedAt || round.startedAt).toLocaleString("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" });
      li.textContent = `第 ${index + 1} 轮 · ${round.completedAt ? "完整读完" : round.endedAt ? "中途重开，未计遍数" : "进行中"} · ${round.lookupCount} 处 / ${round.uniqueWords} 个词条 · ${date}`;
      return li;
    }).reverse());
  }

  function startNewRound() {
    const record = rounds();
    if (!window.confirm(record.current?.completedAt
      ? "开始新一轮？本轮查词标记将清空并回到开头，已完成的阅读记录保留。"
      : "开始新一轮？将清空本轮查词标记并回到开头。本轮尚未在文末确认读完，不计入完整遍数，历史记录仍保留。")) return;
    clearTimeout(saveTimer);
    cancelAnimationFrame(scrollFrame);
    scrollFrame = null;
    cancelAnimationFrame(restoreFrame);
    restoreFrame = null;
    const now = Date.now();
    if (record.current) record.history.push({ ...record.current, ...(!record.current.completedAt ? lookupSummary() : {}), endedAt: now });
    else if (viewedMarks.size || preferences.paragraph > 0 || preferences.offset > 0) {
      record.history.push({ startedAt: now, completedAt: null, endedAt: now, ...lookupSummary() });
    }
    record.current = { startedAt: now, completedAt: null, endedAt: null, lookupCount: 0, uniqueWords: 0 };
    viewedMarks.clear();
    finishedParagraphs.clear();
    preferences.paragraph = 0;
    preferences.offset = 0;
    hideBubble();
    closeQuestions();
    render();
    view.scrollTop = 0;
    persist();
    updateProgress();
  }

  function completeRound() {
    const record = rounds();
    if (record.current?.completedAt) return;
    if (!record.current) record.current = { startedAt: Date.now() };
    Object.assign(record.current, { completedAt: Date.now(), endedAt: null }, lookupSummary());
    Object.assign(preferences, anchor());
    persist();
    $("reader-save-status").textContent = "本轮阅读已完成";
  }

  function hideBubble() {
    if (selected) {
      selected.classList.remove("is-selected");
      selected.setAttribute("aria-expanded", "false");
      selected.removeAttribute("aria-describedby");
    }
    selected = null;
    bubble.classList.add("hidden");
  }

  function anchor() {
    if (!paragraphs.length) return { paragraph: 0, offset: 0 };
    const top = view.getBoundingClientRect().top;
    let low = 0;
    let high = paragraphs.length - 1;
    let index = 0;
    while (low <= high) {
      const middle = Math.floor((low + high) / 2);
      if (paragraphs[middle].getBoundingClientRect().top <= top + 1) {
        index = middle;
        low = middle + 1;
      } else high = middle - 1;
    }
    const rect = paragraphs[index].getBoundingClientRect();
    return { paragraph: index, offset: core.clamp((top - rect.top) / rect.height, 0, 1) };
  }

  function updateProgress() {
    const range = view.scrollHeight - view.clientHeight;
    const percent = range > 0 ? Math.round(view.scrollTop / range * 100) : 0;
    $("reader-progress").textContent = `${percent}%`;
    $("reader-progress-track").value = percent;
    const current = [...data.chapters].reverse().find((chapter) => chapter.start <= preferences.paragraph);
    $("reader-chapter").value = current.id;
    $("open-reader-note").textContent = `${data.wordCount} 词 · ${$("reader-round-note").textContent} · ${percent > 0 ? `继续阅读 ${percent}%` : "可选中英对照"}`;
  }

  function restorePosition() {
    cancelAnimationFrame(restoreFrame);
    restoreFrame = requestAnimationFrame(() => {
      restoreFrame = null;
      if (!active) return;
      const paragraph = paragraphs[preferences.paragraph];
      const rect = paragraph.getBoundingClientRect();
      view.scrollTop += rect.top - view.getBoundingClientRect().top + rect.height * preferences.offset;
      if (preferences.paragraph === 0 && preferences.offset === 0) view.scrollTop = 0;
      updateProgress();
    });
  }

  function applyPreferences() {
    article.style.setProperty("--reader-font-size", `${preferences.fontSize}px`);
    article.style.setProperty("--reader-line-height", preferences.lineHeight);
    article.dataset.font = preferences.fontFamily;
    article.classList.toggle("reader-unmarked", !preferences.underline);
    $("reader-font-size").value = preferences.fontSize;
    $("reader-font-slider").value = preferences.fontSize;
    $("reader-font-smaller").disabled = preferences.fontSize <= 8;
    $("reader-font-larger").disabled = preferences.fontSize >= 40;
    $("reader-line-height").value = preferences.lineHeight;
    $("reader-font-family").value = preferences.fontFamily;
    $("reader-underline").checked = preferences.underline;
    $("reader-show-word").checked = preferences.showWord;
    $("reader-bubble-word").classList.toggle("hidden", !preferences.showWord);
    $("reader-bilingual-toggle").setAttribute("aria-pressed", String(preferences.bilingual));
    $("reader-bilingual-toggle").setAttribute("aria-label", `${preferences.bilingual ? "关闭" : "开启"}中英逐句对照`);
    $("reader-article-note").textContent = `${data.wordCount} 词 · ${preferences.bilingual ? "逐句中英对照" : "纯英文阅读"}`;
  }

  function render() {
    $("reader-questions-list").replaceChildren(...(data.questions || []).map((text) => {
      const item = document.createElement("li");
      item.textContent = text;
      return item;
    }));
    $("reader-questions-toggle").classList.toggle("hidden", !data.questions?.length);
    $("reader-article-select").innerHTML = library.map((item) => `<option value="${core.escapeHTML(item.id)}">${core.escapeHTML(item.label)}</option>`).join("");
    $("reader-article-select").value = data.id;
    $("reader-article-select").parentElement.classList.toggle("hidden", library.length < 2);
    $("reader-chapter").innerHTML = data.chapters.map((chapter) => `<option value="${core.escapeHTML(chapter.id)}">${core.escapeHTML(chapter.label)}</option>`).join("");
    $("reader-chapter").parentElement.classList.toggle("hidden", data.chapters.length < 2);
    article.innerHTML = `<header class="reader-title"><span>${core.escapeHTML(data.label || "阅读文章 1 · 原版合辑")}</span><h1 lang="en">${core.escapeHTML(data.title)}</h1><p>${data.wordCount} 词 · 轻点下划线词查看释义${preferences.bilingual ? " · 重点中文加粗" : ""}</p></header>`
      + data.paragraphs.map((paragraph, index) => {
        const chapter = data.chapters.find((item) => item.start === index && index > 0);
        const divider = chapter ? `<div class="reader-divider"><span>${core.escapeHTML(chapter.label)}</span></div>` : "";
        const html = preferences.bilingual ? core.bilingualParagraphHTML(paragraph, index) : core.paragraphHTML(paragraph, index);
        if (data.paragraphGroups) {
          const startsGroup = data.paragraphGroups.includes(index);
          const endsGroup = data.paragraphGroups.includes(index + 1);
          return `${startsGroup ? `<p class="reader-paragraph"${preferences.bilingual ? "" : ' lang="en"'}>` : " "}<span class="reader-segment" data-index="${index}">${html}</span>${endsGroup ? "</p>" : ""}`;
        }
        return `${divider}<p class="reader-paragraph"${preferences.bilingual ? "" : ' lang="en"'} data-index="${index}">${html}</p>`;
      }).join("") + '<div class="reader-end"><p>— 全文完 —</p><button type="button" id="reader-complete-round" class="reader-round-button">本轮读完</button></div>';
    paragraphs = Array.from(article.querySelectorAll(data.paragraphGroups ? ".reader-segment" : ".reader-paragraph"));
    article.querySelectorAll(".reader-word").forEach((button) => {
      if (viewedMarks.has(`${button.dataset.paragraph}:${button.dataset.mark}`)) emphasizeViewed(button);
    });
    rendered = true;
    updateRoundUI();
  }

  function enter() {
    if (!data || !core) {
      $("reader-error").classList.remove("hidden");
      return;
    }
    active = true;
    window.ReadingTimer?.enter();
    if (!rounds().current) rounds().current = { startedAt: Date.now(), completedAt: null, endedAt: null, ...lookupSummary() };
    if (!rendered) render();
    applyPreferences();
    restorePosition();
    persist();
    $("reader-back").focus({ preventScroll: true });
  }

  function leave() {
    window.ReadingTimer?.leave();
    closeQuestions();
    if (active && rendered) {
      Object.assign(preferences, anchor());
      persist();
    }
    active = false;
    cancelAnimationFrame(restoreFrame);
    clearTimeout(saveTimer);
    hideBubble();
    $("reader-options").classList.add("hidden");
    $("reader-options-toggle").setAttribute("aria-expanded", "false");
  }

  function showBubble(button, event) {
    if (selected === button) { hideBubble(); return; }
    hideBubble();
    const entry = core.definition(data, Number(button.dataset.paragraph), Number(button.dataset.mark));
    if (!entry) return;
    const pi = Number(button.dataset.paragraph);
    const mi = Number(button.dataset.mark);
    const boundaries = data.paragraphGroups || [...data.paragraphs.map((_, i) => i), data.paragraphs.length];
    const group = boundaries.slice(1).findIndex((end) => end - 1 === pi);
    const lastMark = data.paragraphs[pi].marks.reduce((last, mark, index, marks) =>
      last < 0 || mark[1] > marks[last][1] ? index : last, -1);
    if (group >= 0 && mi === lastMark && !finishedParagraphs.has(group)) {
      finishedParagraphs.add(group);
      window.ReadingTimer?.cheerParagraph(group + 1, boundaries.length - 1);
      persist();
    }
    const key = `${button.dataset.paragraph}:${button.dataset.mark}`;
    if (!viewedMarks.has(key)) {
      viewedMarks.add(key);
      emphasizeViewed(button);
      persist();
    }
    selected = button;
    button.classList.add("is-selected");
    button.setAttribute("aria-expanded", "true");
    button.setAttribute("aria-describedby", "reader-bubble");
    $("reader-bubble-word").textContent = preferences.showWord ? entry.word : "";
    $("reader-bubble-meaning").textContent = entry.meaning;
    const related = $("reader-bubble-related");
    related.replaceChildren(...entry.related.map(([word, meaning]) => {
      const line = document.createElement("div");
      const english = document.createElement("b");
      english.textContent = `${word}:`;
      line.append(english, document.createTextNode(` ${meaning}`));
      return line;
    }));
    related.classList.toggle("hidden", entry.related.length === 0);
    bubble.classList.remove("hidden");
    const viewRect = view.getBoundingClientRect();
    const bounds = { left: Math.max(10, viewRect.left + 8), right: Math.min(window.innerWidth - 10, viewRect.right - 8),
      top: viewRect.top + 6, bottom: viewRect.bottom - 6 };
    bubble.style.maxWidth = `${Math.min(300, bounds.right - bounds.left)}px`;
    bubble.style.maxHeight = `${Math.max(48, bounds.bottom - bounds.top)}px`;
    const rects = Array.from(button.getClientRects());
    const rect = rects.find((r) => event.clientY >= r.top && event.clientY <= r.bottom) || button.getBoundingClientRect();
    const position = core.bubblePosition(rect, bubble.getBoundingClientRect(), bounds);
    bubble.style.left = `${position.left}px`;
    bubble.style.top = `${position.top}px`;
    bubble.style.setProperty("--bubble-arrow", `${position.arrow}px`);
    bubble.classList.toggle("below-word", position.below);
  }

  function emphasizeViewed(button) {
    button.classList.add("is-looked-up");
    button.setAttribute("aria-label", `${button.textContent}，已查看释义`);
  }

  function closeOptions() {
    $("reader-options").classList.add("hidden");
    $("reader-options-toggle").setAttribute("aria-expanded", "false");
  }

  function closeQuestions(restoreFocus = false) {
    $("reader-questions").classList.add("hidden");
    $("reader-questions-toggle").setAttribute("aria-expanded", "false");
    if (restoreFocus) $("reader-questions-toggle").focus({ preventScroll: true });
  }
  $("reader-questions-toggle").addEventListener("click", () => {
    const open = $("reader-questions").classList.toggle("hidden") === false;
    $("reader-questions-toggle").setAttribute("aria-expanded", String(open));
    hideBubble();
    closeOptions();
    if (open) $("reader-questions-close").focus({ preventScroll: true });
  });
  $("reader-questions-close").addEventListener("click", () => closeQuestions(true));

  article.addEventListener("click", (event) => {
    if (event.target.closest("#reader-complete-round")) { completeRound(); return; }
    const button = event.target.closest(".reader-word");
    if (button) showBubble(button, event);
  });
  $("reader-new-round").addEventListener("click", startNewRound);
  article.addEventListener("keydown", (event) => {
    if ((event.key === "Enter" || event.key === " ") && event.target.classList.contains("reader-word")) {
      event.preventDefault();
      if (!event.repeat) showBubble(event.target, event);
    }
  });
  document.addEventListener("pointerdown", (event) => {
    if (!event.target.closest(".reader-word, #reader-bubble")) hideBubble();
    if (active && !event.target.closest("#reader-options, #reader-options-toggle")) closeOptions();
  });
  document.addEventListener("focusin", (event) => {
    if (selected && event.target !== selected && !bubble.contains(event.target)) hideBubble();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && active) {
      if (!$("reader-questions").classList.contains("hidden")) {
        closeQuestions(true);
        return;
      }
      hideBubble();
      closeOptions();
      $("reader-options-toggle").focus({ preventScroll: true });
    }
  });
  view.addEventListener("scroll", () => {
    hideBubble();
    if (!active || scrollFrame) return;
    scrollFrame = requestAnimationFrame(() => {
      scrollFrame = null;
      if (!active) return;
      Object.assign(preferences, anchor());
      updateProgress();
      clearTimeout(saveTimer);
      saveTimer = setTimeout(persist, 200);
    });
  }, { passive: true });

  $("reader-options-toggle").addEventListener("click", () => {
    const open = $("reader-options").classList.toggle("hidden") === false;
    $("reader-options-toggle").setAttribute("aria-expanded", String(open));
    hideBubble();
  });
  $("reader-options-close").addEventListener("click", () => {
    closeOptions();
    $("reader-options-toggle").focus({ preventScroll: true });
  });
  function changeLayout(update) {
    // Rapid slider input may arrive before the previous layout has restored
    // its position. Keep that pending anchor instead of measuring shifted text.
    if (!restoreFrame) Object.assign(preferences, anchor());
    const bilingualChanged = "bilingual" in update && preferences.bilingual !== update.bilingual;
    Object.assign(preferences, core.normalizePreferences({ ...preferences, ...update }, data.paragraphs.length));
    hideBubble();
    if (bilingualChanged) render();
    applyPreferences();
    restorePosition();
    persist();
  }
  $("reader-font-smaller").addEventListener("click", () => changeLayout({ fontSize: preferences.fontSize - 1 }));
  $("reader-bilingual-toggle").addEventListener("click", () => changeLayout({ bilingual: !preferences.bilingual }));
  $("reader-font-larger").addEventListener("click", () => changeLayout({ fontSize: preferences.fontSize + 1 }));
  $("reader-font-slider").addEventListener("input", (event) => changeLayout({ fontSize: Number(event.target.value) }));
  $("reader-font-size").addEventListener("change", (event) => {
    if (!event.target.value.trim()) { applyPreferences(); return; }
    changeLayout({ fontSize: Number(event.target.value) });
  });
  $("reader-font-size").addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.target.blur(); closeOptions(); }
  });
  $("reader-line-height").addEventListener("change", (event) => changeLayout({ lineHeight: Number(event.target.value) }));
  $("reader-font-family").addEventListener("change", (event) => changeLayout({ fontFamily: event.target.value }));
  $("reader-reset-layout").addEventListener("click", () => changeLayout({ fontSize: 16, lineHeight: 1.6, fontFamily: "sans" }));
  $("reader-underline").addEventListener("change", (event) => {
    preferences.underline = event.target.checked;
    applyPreferences();
    persist();
  });
  $("reader-show-word").addEventListener("change", (event) => {
    preferences.showWord = event.target.checked;
    hideBubble();
    applyPreferences();
    persist();
  });
  $("reader-chapter").addEventListener("change", (event) => {
    preferences.paragraph = data.chapters.find((chapter) => chapter.id === event.target.value).start;
    preferences.offset = 0;
    hideBubble();
    restorePosition();
    persist();
  });
  $("reader-article-select").addEventListener("change", (event) => {
    const next = library.find((item) => item.id === event.target.value);
    if (!next || next === data) return;
    if (!restoreFrame) Object.assign(preferences, anchor());
    clearTimeout(saveTimer);
    cancelAnimationFrame(scrollFrame);
    scrollFrame = null;
    hideBubble();
    persist();
    data = next;
    const saved = articleStates[data.id] || {};
    preferences = core.normalizePreferences({ ...preferences, paragraph: saved.paragraph || 0, offset: saved.offset || 0 }, data.paragraphs.length);
    viewedMarks = new Set(core.normalizeViewedMarks(saved.viewedMarks, data));
    finishedParagraphs = normalizeParagraphs(paragraphCompletions[data.id]);
    render();
    applyPreferences();
    restorePosition();
    persist();
  });
  window.addEventListener("resize", () => { if (active) { hideBubble(); restorePosition(); } });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && active) { Object.assign(preferences, anchor()); persist(); hideBubble(); }
  });
  window.addEventListener("pagehide", () => { if (active) { Object.assign(preferences, anchor()); persist(); } });
  function exportReadingData() {
    if (active && rendered) Object.assign(preferences, anchor());
    persist();
    return JSON.parse(JSON.stringify({ articleId: data.id, preferences, articles: articleStates, readingRounds, paragraphCompletions,
      timer: window.ReadingTimer?.exportState() }));
  }
  function restoreReadingData(raw) {
    if (!raw || raw.timer) window.ReadingTimer?.restoreState(raw?.timer);
    clearTimeout(saveTimer);
    cancelAnimationFrame(restoreFrame);
    restoreFrame = null;
    cancelAnimationFrame(scrollFrame);
    scrollFrame = null;
    const state = core.normalizeLibraryState(raw, library);
    data = library.find((item) => item.id === state.articleId);
    articleStates = state.articles;
    preferences = core.normalizePreferences({ ...state.preferences, ...articleStates[data.id] }, data.paragraphs.length);
    viewedMarks = new Set(articleStates[data.id].viewedMarks);
    readingRounds = Object.fromEntries(library.map((item) => [item.id, core.normalizeReadingRounds(raw?.readingRounds?.[item.id])]));
    paragraphCompletions = raw?.paragraphCompletions && typeof raw.paragraphCompletions === "object" && !Array.isArray(raw.paragraphCompletions) ? raw.paragraphCompletions : {};
    finishedParagraphs = normalizeParagraphs(paragraphCompletions[data.id]);
    hideBubble();
    rendered = false;
    if (active) { render(); applyPreferences(); restorePosition(); }
    persist();
  }
  renderRecords();
  window.AppReader = { enter, leave, renderRecords, exportReadingData, restoreReadingData };
})();
