(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.ReaderCore = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";

  function clamp(value, min, max) {
    const number = Number(value);
    return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : min;
  }

  function normalizePreferences(raw = {}, paragraphCount = 1) {
    if (!raw || typeof raw !== "object") raw = {};
    return {
      fontSize: Math.round(clamp(raw.fontSize ?? 16, 8, 40)),
      lineHeight: [1.4, 1.6, 1.8, 2].includes(Number(raw.lineHeight)) ? Number(raw.lineHeight) : 1.6,
      fontFamily: raw.fontFamily === "serif" ? "serif" : "sans",
      underline: raw.underline !== false,
      showWord: raw.showWord === true,
      bilingual: raw.bilingual === true,
      paragraph: Math.floor(clamp(raw.paragraph ?? 0, 0, paragraphCount - 1)),
      offset: clamp(raw.offset ?? 0, 0, 1),
    };
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    })[character]);
  }

  function normalizeViewedMarks(raw, data) {
    if (!Array.isArray(raw)) return [];
    return [...new Set(raw.filter((key) => {
      if (typeof key !== "string" || !/^\d+:\d+$/.test(key)) return false;
      const [paragraph, mark] = key.split(":").map(Number);
      return Boolean(data.paragraphs[paragraph]?.marks[mark]);
    }))];
  }

  function paragraphHTML(paragraph, index, start = 0, end = paragraph.text.length) {
    let cursor = start;
    const parts = [];
    paragraph.marks.map((span, mark) => ({ span, mark })).sort((a, b) => a.span[0] - b.span[0]).forEach(({ span: [a, b], mark }) => {
      if (b <= start || a >= end) return;
      if (a < cursor || b <= a || b > end) throw new Error("无效的阅读标记");
      parts.push(escapeHTML(paragraph.text.slice(cursor, a)));
      // An inline text control lets phrases wrap naturally with surrounding
      // punctuation. Native buttons form atomic boxes and can orphan full stops.
      parts.push(`<span role="button" tabindex="0" class="reader-word" data-paragraph="${index}" data-mark="${mark}" aria-expanded="false">${escapeHTML(paragraph.text.slice(a, b))}</span>`);
      cursor = b;
    });
    parts.push(escapeHTML(paragraph.text.slice(cursor, end)));
    return parts.join("");
  }

  function translationHTML(text) {
    // Only authored emphasis is accepted; arbitrary HTML is never interpreted.
    return String(text).split("**").map((part, index) => index % 2
      ? `<strong>${escapeHTML(part)}</strong>` : escapeHTML(part)).join("");
  }

  function bilingualParagraphHTML(paragraph, index) {
    if (!paragraph.sentences?.length) return paragraphHTML(paragraph, index);
    let cursor = 0;
    const html = paragraph.sentences.map((sentence, sentenceIndex) => {
      if (sentence.start !== cursor || sentence.end <= cursor || sentence.end > paragraph.text.length || !sentence.zh) {
        throw new Error("无效的逐句译文");
      }
      cursor = sentence.end;
      return `<span class="reader-sentence" data-sentence="${sentenceIndex}"><span class="reader-english" lang="en">${paragraphHTML(paragraph, index, sentence.start, sentence.end)}</span><span class="reader-translation" lang="zh-CN">${translationHTML(sentence.zh)}</span></span>`;
    }).join("");
    if (cursor !== paragraph.text.length) throw new Error("逐句译文未覆盖完整段落");
    return html;
  }

  function normalizeLibraryState(raw, library, legacy) {
    if (!raw || typeof raw !== "object") raw = {};
    const articleId = library.some((item) => item.id === raw.articleId) ? raw.articleId : library[0].id;
    const articles = {};
    for (const item of library) {
      const saved = raw.articles?.[item.id] || (legacy?.articleId === item.id ? legacy : {});
      const prefs = normalizePreferences(saved, item.paragraphs.length);
      articles[item.id] = { paragraph: prefs.paragraph, offset: prefs.offset,
        viewedMarks: normalizeViewedMarks(saved.viewedMarks, item) };
    }
    return { articleId, preferences: normalizePreferences(raw.preferences || legacy || {}), articles };
  }

  function definition(data, paragraphIndex, markIndex) {
    const paragraph = data.paragraphs[paragraphIndex];
    const mark = paragraph?.marks[markIndex];
    if (!mark) return null;
    const dictionary = data.dictionaries.find((item) => item.id === paragraph.source);
    const meaning = dictionary?.words[mark[2]] || data.additionalDictionary?.[mark[2]];
    if (!meaning) return null;
    return { word: mark[2], meaning, source: dictionary?.title, related: Array.isArray(mark[3]) ? mark[3] : [] };
  }

  function normalizeReadingRounds(raw) {
    const normalize = (item) => {
      if (!item || typeof item !== "object" || !Number.isFinite(item.startedAt) || item.startedAt <= 0) return null;
      return { startedAt: item.startedAt,
        completedAt: Number.isFinite(item.completedAt) && item.completedAt >= item.startedAt ? item.completedAt : null,
        endedAt: Number.isFinite(item.endedAt) && item.endedAt >= item.startedAt ? item.endedAt : null,
        lookupCount: Math.floor(clamp(item.lookupCount ?? 0, 0, 1000000)),
        uniqueWords: Math.floor(clamp(item.uniqueWords ?? 0, 0, 1000000)),
        paragraphCount: Math.floor(clamp(item.paragraphCount ?? 0, 0, 1000000)) };
    };
    return { current: normalize(raw?.current),
      history: Array.isArray(raw?.history) ? raw.history.map(normalize).filter(Boolean) : [] };
  }

  function timerRemaining(timer, now = Date.now()) {
    return Math.max(0, timer.status === "running" ? timer.deadline - now : timer.remainingMs);
  }

  function normalizeReadingTimer(raw, now = Date.now()) {
    const durationMs = Math.round(clamp(raw?.durationMs ?? 1440000, 60000, 10800000) / 60000) * 60000;
    let remainingMs = clamp(raw?.remainingMs ?? durationMs, 0, durationMs);
    let status = ["idle", "paused", "finished"].includes(raw?.status) ? raw.status : "idle";
    let pending = raw?.pending === true;
    if (raw?.status === "running" && Number.isFinite(raw.deadline)) {
      remainingMs = clamp(raw.deadline - now, 0, durationMs);
      status = remainingMs > 0 ? "paused" : "finished";
      pending = remainingMs === 0;
    }
    if (status === "idle") remainingMs = durationMs;
    if (status === "finished" || remainingMs === 0) { status = "finished"; remainingMs = 0; }
    return { durationMs, remainingMs, status, deadline: null, pending: status === "finished" && pending };
  }

  // All coordinates are viewport-relative. Prefer above the touched word, but
  // keep the entire bubble inside the reading area, including on narrow phones.
  function bubblePosition(anchor, bubble, bounds) {
    const gap = 9;
    const left = clamp(anchor.left + anchor.width / 2 - bubble.width / 2,
      bounds.left, Math.max(bounds.left, bounds.right - bubble.width));
    const above = anchor.top - bubble.height - gap;
    const below = above < bounds.top;
    const top = clamp(below ? anchor.bottom + gap : above,
      bounds.top, Math.max(bounds.top, bounds.bottom - bubble.height));
    return { left, top, below, arrow: clamp(anchor.left + anchor.width / 2 - left, 16, bubble.width - 16) };
  }

  return { clamp, normalizePreferences, normalizeViewedMarks, normalizeLibraryState, escapeHTML, paragraphHTML,
    bilingualParagraphHTML, translationHTML, definition, bubblePosition, normalizeReadingRounds,
    timerRemaining, normalizeReadingTimer };
});
