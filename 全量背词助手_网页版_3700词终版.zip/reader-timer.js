/* Local, deadline-based reading timer. No network, sound or completion credit. */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const core = window.ReaderCore;
  const KEY = "gaokao-word-app-reading-timer-v1";
  let saved;
  try { saved = JSON.parse(localStorage.getItem(KEY)); } catch (_) { /* Optional storage. */ }
  let timer = core.normalizeReadingTimer(saved);
  let active = false;
  let ticker;
  let celebrationTimeout;
  const cheerQueue = [];

  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(timer)); } catch (_) { /* Still works in memory. */ }
  }

  function render() {
    const seconds = Math.ceil(core.timerRemaining(timer) / 1000);
    const text = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
    $("reader-timer-toggle").textContent = text;
    $("reader-timer-toggle").dataset.status = timer.status;
    const state = { running: "计时中", paused: "已暂停", idle: "未开始", finished: "已完成" }[timer.status];
    $("reader-timer-toggle").setAttribute("aria-label", `阅读倒计时 ${text}，${state}，点击设置`);
    $("reader-timer-pause").textContent = timer.status === "running" ? "暂停" : timer.status === "paused" ? "继续" : timer.status === "finished" ? "再来一次" : "开始";
    document.querySelectorAll("[data-reader-minutes]").forEach((button) => {
      button.setAttribute("aria-pressed", String(Number(button.dataset.readerMinutes) * 60000 === timer.durationMs));
    });
  }

  function hideCelebration(clearQueue = true) {
    clearTimeout(celebrationTimeout);
    if (clearQueue) cheerQueue.length = 0;
    $("reader-timer-celebration").classList.add("hidden");
    $("reader-timer-cheer").textContent = "";
    $("reader-timer-fireworks").replaceChildren();
  }

  function celebrate() {
    if (!active || document.hidden || !timer.pending) return;
    timer.pending = false;
    persist();
    showCheer(`${timer.durationMs / 60000} 分钟，到点啦。做得好，歇口气也很棒！`);
  }

  function showCheer(message, small = false) {
    if (!active || document.hidden) return;
    if (!$("reader-timer-celebration").classList.contains("hidden")) {
      cheerQueue.push([message, small]);
      return;
    }
    $("reader-timer-celebration").classList.remove("hidden");
    $("reader-timer-celebration").classList.toggle("is-small", small);
    $("reader-timer-cheer").textContent = message;
    if (!matchMedia("(prefers-reduced-motion: reduce)").matches && $("animation-enabled")?.checked !== false) {
      const colors = ["#c88932", "#4c9b8b", "#c5778d"];
      for (let burst = 0; burst < (small ? 1 : 3); burst += 1) {
        const origin = document.createElement("span");
        origin.className = "reader-timer-burst";
        origin.style.left = `${small ? 50 : 20 + burst * 30}%`;
        origin.style.top = `${burst === 1 ? 4 : 26}px`;
        for (let i = 0; i < 12; i += 1) {
          const dot = document.createElement("i");
          const angle = i * Math.PI / 6;
          dot.style.setProperty("--dx", `${Math.cos(angle) * 52}px`);
          dot.style.setProperty("--dy", `${Math.sin(angle) * 44}px`);
          dot.style.setProperty("--delay", `${burst * 180}ms`);
          dot.style.background = colors[burst];
          origin.appendChild(dot);
        }
        $("reader-timer-fireworks").appendChild(origin);
      }
    }
    celebrationTimeout = setTimeout(() => {
      hideCelebration(false);
      const next = cheerQueue.shift();
      if (next) showCheer(...next);
    }, small ? 2400 : 4500);
  }

  function tick() {
    if (timer.status === "running" && core.timerRemaining(timer) === 0) {
      clearInterval(ticker);
      ticker = null;
      Object.assign(timer, { status: "finished", remainingMs: 0, deadline: null, pending: true });
      persist();
      closePanel();
      celebrate();
    }
    render();
  }

  function pause() {
    if (timer.status !== "running") return;
    tick();
    if (timer.status !== "running") return;
    if (core.timerRemaining(timer) === 0) { tick(); return; }
    timer.remainingMs = core.timerRemaining(timer);
    timer.deadline = null;
    timer.status = "paused";
    clearInterval(ticker);
    ticker = null;
    persist();
    render();
  }

  function resume() {
    if (!active || document.hidden || timer.status === "running") return;
    hideCelebration();
    if (timer.status === "finished" || timer.status === "idle") timer.remainingMs = timer.durationMs;
    timer.status = "running";
    timer.pending = false;
    timer.deadline = Date.now() + timer.remainingMs;
    persist();
    clearInterval(ticker);
    ticker = setInterval(tick, 250);
    tick();
    closePanel();
  }

  function start(minutes) {
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 180) return;
    clearInterval(ticker);
    timer = core.normalizeReadingTimer({ durationMs: minutes * 60000 });
    $("reader-timer-minutes").value = String(minutes);
    resume();
  }

  function closePanel(restoreFocus = false) {
    $("reader-timer-panel").classList.add("hidden");
    $("reader-timer-toggle").setAttribute("aria-expanded", "false");
    if (restoreFocus || $("reader-timer-panel").contains(document.activeElement)) {
      $("reader-timer-toggle").focus({ preventScroll: true });
    }
  }

  $("reader-timer-toggle").addEventListener("click", () => {
    const open = $("reader-timer-panel").classList.toggle("hidden") === false;
    $("reader-timer-toggle").setAttribute("aria-expanded", String(open));
    if (open) {
      $("reader-options").classList.add("hidden");
      $("reader-options-toggle").setAttribute("aria-expanded", "false");
      $("reader-questions").classList.add("hidden");
      $("reader-questions-toggle").setAttribute("aria-expanded", "false");
      $("reader-timer-close").focus({ preventScroll: true });
    }
  });
  $("reader-timer-close").addEventListener("click", () => closePanel(true));
  document.querySelectorAll("[data-reader-minutes]").forEach((button) => {
    button.addEventListener("click", () => start(Number(button.dataset.readerMinutes)));
  });
  $("reader-timer-form").addEventListener("submit", (event) => {
    event.preventDefault();
    if (event.currentTarget.reportValidity()) start(Number($("reader-timer-minutes").value));
  });
  $("reader-timer-pause").addEventListener("click", () => { if (timer.status === "running") pause(); else resume(); });
  $("reader-timer-reset").addEventListener("click", () => {
    clearInterval(ticker);
    ticker = null;
    timer = core.normalizeReadingTimer({ durationMs: timer.durationMs });
    hideCelebration();
    persist();
    render();
  });
  document.addEventListener("pointerdown", (event) => {
    if (!event.target.closest("#reader-timer-panel, #reader-timer-toggle")) closePanel();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !$("reader-timer-panel").classList.contains("hidden")) {
      event.stopImmediatePropagation();
      closePanel(true);
    }
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) { pause(); hideCelebration(); } else celebrate();
  });
  window.addEventListener("pagehide", pause);
  $("reader-timer-minutes").value = String(timer.durationMs / 60000);
  persist();
  render();
  window.ReadingTimer = {
    enter() { active = true; render(); celebrate(); },
    leave() { active = false; pause(); closePanel(); hideCelebration(); },
    exportState() { return { ...timer, remainingMs: core.timerRemaining(timer),
      status: timer.status === "running" ? "paused" : timer.status, deadline: null }; },
    restoreState(raw) {
      clearInterval(ticker);
      ticker = null;
      hideCelebration();
      timer = core.normalizeReadingTimer(raw);
      $("reader-timer-minutes").value = String(timer.durationMs / 60000);
      persist();
      render();
      celebrate();
    },
    cheerParagraph(number, total) { showCheer(`第 ${number}/${total} 段，拿下。又前进一小步！`, true); },
  };
})();
