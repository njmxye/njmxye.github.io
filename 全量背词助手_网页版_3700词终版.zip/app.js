const STORAGE_KEY = "gaokao-word-app-state-v1";
const VERSION = 10;
const POWER_ACCOUNTING_VERSION = 1;
const BUILTIN_WORDSET_ID = "gaokao-final-2280-20261010";
const STUDY_ORDER_MODES = ["familiarity-alpha", "familiarity-random"];
const STUDY_MODES = ["recall", "dictation"];
const BOOK_SCOPES = ["new", "weak", "mastered"];
const SESSION_SCOPES = [...BOOK_SCOPES, "legacy", "reinforce"];
const WORD_PACKAGE_TYPE = "gaokao-word-list";
const WORD_PACKAGE_VERSION = 1;
const WORD_ROW_HEIGHT = 82;
const VIRTUAL_OVERSCAN = 8;
const LIBRARY_BOTTOM_GUTTER = 120;

const SHOP_ITEMS = [
  { id: "double-xp", title: "双倍研习", type: "boost", price: 300, description: "接下来 20 次有效判断获得双倍 XP。", icon: "×2" },
  { id: "double-xp-large", title: "双倍研习·长线", type: "boost", price: 1200, description: "接下来 100 次有效判断获得双倍 XP。", icon: "×4" },
  { id: "combo-charm", title: "连击护符", type: "boost", price: 220, description: "下一次模糊不会清空连击。", icon: "连" },
  { id: "combo-charm-pack", title: "连击护符包", type: "boost", price: 900, description: "一次获得 5 枚连击护符，适合长线冲刺。", icon: "连5" },
  { id: "extra-relief", title: "加练减负", type: "boost", price: 260, description: "接下来 10 次生词结果只安排一次加练。", icon: "练" },
  { id: "extra-relief-large", title: "加练减负·长线", type: "boost", price: 1000, description: "接下来 50 次生词结果只安排一次加练。", icon: "练50" },
  { id: "stage-insurance", title: "阶段保险", type: "boost", price: 1400, description: "接下来 3 个阶段完成时额外获得 100 XP。", icon: "段" },
  { id: "focus-shield", title: "低谷护盾", type: "boost", price: 1600, description: "接下来 10 次不认识不会清空连击。", icon: "盾" },
  { id: "ochre-seal", title: "赭金印章", type: "cosmetic", price: 450, description: "解锁首页与学习页的赭金战力印章。", icon: "印" },
  { id: "vermillion-seal", title: "朱砂印章", type: "cosmetic", price: 700, description: "解锁朱砂色战力印章，装备后更醒目。", icon: "朱" },
  { id: "jade-seal", title: "青瓷印章", type: "cosmetic", price: 900, description: "解锁青瓷色战力印章，适合低刺激学习。", icon: "瓷" },
  { id: "collection-frame", title: "藏品边框", type: "cosmetic", price: 650, description: "解锁成就卡片的高级收藏边框。", icon: "框" },
  { id: "gold-frame", title: "金榜边框", type: "cosmetic", price: 1800, description: "解锁更高阶的成就收藏边框。", icon: "榜" },
  { id: "full-runner", title: "全量行者", type: "cosmetic", price: 900, description: "解锁个人档案与结果页称号。", icon: "行" },
  { id: "scholar-title", title: "持卷人称号", type: "cosmetic", price: 2200, description: "解锁个人档案的进阶称号。", icon: "卷" },
];

const $ = (id) => document.getElementById(id);
const screens = { home: $("home-screen"), study: $("study-screen"), library: $("library-screen"), achievements: $("achievements-screen"), profile: $("profile-screen"), result: $("result-screen"), reader: $("reader-screen") };

const ACHIEVEMENTS = [
  { id: "start", title: "启程", description: "完成第一次有效提取", reward: 80, test: (stats) => stats.recalls >= 1 },
  { id: "hundred", title: "热身完成", description: "累计有效提取 100 次", reward: 100, test: (stats) => stats.recalls >= 100 },
  { id: "five-hundred", title: "五百次回响", description: "累计有效提取 500 次", reward: 150, test: (stats) => stats.recalls >= 500 },
  { id: "stage", title: "小段落成", description: "完成第一个 20 词阶段", reward: 100, test: (stats) => stats.stageCompletions >= 1 },
  { id: "hour", title: "进入状态", description: "累计学习 1 小时", reward: 120, test: (stats) => stats.activeMs >= 3600000 },
  { id: "five-hours", title: "五小时线", description: "累计学习 5 小时", reward: 150, test: (stats) => stats.activeMs >= 18000000 },
  { id: "first-checkin", title: "今日不空", description: "第一次完成每日目标", reward: 120, test: (stats) => stats.checkins >= 1 },
  { id: "three-days", title: "三日不熄", description: "连续学习 3 天", reward: 150, test: (stats) => stats.currentStreak >= 3 },
  { id: "round", title: "整轮通关", description: "完成第一轮词本全量", reward: 250, test: (stats) => stats.rounds >= 1 },
  { id: "three-rounds", title: "三轮推进", description: "完成三轮全量训练", reward: 300, test: (stats) => stats.rounds >= 3 },
  { id: "ten-hours", title: "十小时战线", description: "累计学习 10 小时", reward: 350, test: (stats) => stats.activeMs >= 36000000 },
  { id: "seven-days", title: "一周成习", description: "连续学习 7 天", reward: 400, test: (stats) => stats.currentStreak >= 7 },
  { id: "combo-10", title: "连击启动", description: "达成 10 连击", reward: 280, test: (stats) => stats.bestCombo >= 10 },
  { id: "combo-25", title: "节奏掌控", description: "达成 25 连击", reward: 350, test: (stats) => stats.bestCombo >= 25 },
  { id: "power-1000", title: "战力破千", description: "单日战力达到 1000", reward: 450, test: (stats) => stats.bestPower >= 1000 },
  { id: "familiarity-40", title: "渐入佳境", description: "词表平均熟识度达到 40", reward: 400, test: (stats) => stats.familiarityAverage >= 40 },
  { id: "fifty-hours", title: "长线作战", description: "累计学习 50 小时", reward: 800, test: (stats) => stats.activeMs >= 180000000 },
  { id: "century", title: "百小时档案", description: "累计学习 100 小时", reward: 1000, test: (stats) => stats.activeMs >= 360000000 },
  { id: "thirty-days", title: "一月成习", description: "连续学习 30 天", reward: 1000, test: (stats) => stats.currentStreak >= 30 },
  { id: "ten-rounds", title: "十轮不退", description: "完成十轮全量训练", reward: 900, test: (stats) => stats.rounds >= 10 },
  { id: "combo-50", title: "心流连斩", description: "达成 50 连击", reward: 1200, test: (stats) => stats.bestCombo >= 50 },
  { id: "familiarity-70", title: "词表成林", description: "词表平均熟识度达到 70", reward: 1200, test: (stats) => stats.familiarityAverage >= 70 },
  { id: "shop-first", title: "第一次兑换", description: "解锁第一件商店商品", reward: 800, test: (stats) => stats.shopUnlocks >= 1 },
  { id: "power-spent-3000", title: "把战力用起来", description: "累计消费 3000 战力", reward: 1500, test: (stats) => stats.powerSpent >= 3000 },
];

let words = [];
let builtinWords = [];
let state = loadState();
let session = null;
let timerHandle = null;
let saveHandle = null;
let toastHandle = null;
let audioContext = null;
let audioBus = null;
let calendarYear = new Date().getFullYear();
let calendarMonth = new Date().getMonth();
let librarySearch = "";
let libraryFamiliarityFilter = "all";
let libraryBookFilter = "all";
let selectedWordIds = new Set();
let filteredLibraryWords = [];
let libraryThumbDragging = false;
let libraryRenderFrame = 0;
let libraryLoaded = false;
let nextCardHandle = null;
let editingWordId = null;
let resultScope = "new";

function todayKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function studyModeLabel(mode = state.settings.studyMode) {
  return mode === "dictation" ? "中文默写" : "看词回忆";
}

function bookLabel(scope) {
  return { new: "新词本", weak: "生词本", mastered: "熟词本", legacy: "旧版全量", reinforce: "重点加练" }[scope] || "词本";
}

function wordBookStatus(item) {
  if (item.book === "weak") return `连续正确 ${item.dictationCorrectStreak} / 10`;
  if (item.book === "mastered") return `连续错误 ${item.dictationWrongStreak} / 2`;
  return "待首次默写";
}

function getBookCounts() {
  const counts = { new: 0, weak: 0, mastered: 0 };
  words.forEach((word) => { counts[getWordProgress(word).book] += 1; });
  return counts;
}

function defaultState() {
  return {
    version: VERSION,
    savedAt: null,
    progress: {},
    daily: {},
    settings: { revealSeconds: 4, goalMinutes: 600, sound: true, soundVolume: 1.6, animation: true, theme: "aurora", studyOrder: "familiarity-alpha", studyMode: "recall" },
    totalActiveMs: 0,
    totalXp: 0,
    powerBalance: 0,
    totalPowerEarned: 0,
    totalPowerSpent: 0,
    powerMigrationDone: true,
    powerAccountingVersion: POWER_ACCOUNTING_VERSION,
    bestCombo: 0,
    streak: 0,
    lastStudyDate: null,
    milestones: { comboRewards: {} },
    shop: {
      owned: {},
      activeBoosts: { doubleXpRemaining: 0, comboCharm: 0, extraReliefRemaining: 0, stageBonusRemaining: 0, unknownShield: 0 },
      unlockedCosmetics: {},
      equippedCosmetics: {},
    },
    achievements: { unlockedAt: {}, rewardGranted: {}, rewardClaimed: {} },
    library: { mode: "builtin", builtinWordsetId: BUILTIN_WORDSET_ID, customPackage: null, builtinProgress: {} },
    reinforcementPool: { wordIds: [], sourceRound: 0, createdAt: null },
    sessionsByScope: {},
    activeSessionScope: null,
    session: null,
  };
}

function nonNegativeNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, number) : 0;
}

function deriveLegacyPower(parsed = {}) {
  const days = Object.values(parsed.daily || {});
  const historicalPower = days.reduce((sum, day) => sum + getPower(day), 0);
  const roundAndRecallPower = days.reduce((sum, day) => sum + nonNegativeNumber(day.standardRounds) * 120 + nonNegativeNumber(day.known) * 2, 0);
  const fallbackPower = Math.floor(nonNegativeNumber(parsed.totalXp) + nonNegativeNumber(parsed.totalActiveMs) / 60000 * 2 + roundAndRecallPower);
  return Math.max(historicalPower, fallbackPower);
}

function normalizeState(parsed = {}) {
  const defaults = defaultState();
  const next = { ...defaults, ...parsed, settings: { ...defaults.settings, ...(parsed.settings || {}) } };
  if (!STUDY_ORDER_MODES.includes(next.settings.studyOrder)) next.settings.studyOrder = defaults.settings.studyOrder;
  if (!STUDY_MODES.includes(next.settings.studyMode)) next.settings.studyMode = defaults.settings.studyMode;
  next.milestones = { ...defaults.milestones, ...(parsed.milestones || {}), comboRewards: { ...(parsed.milestones?.comboRewards || {}) } };
  next.shop = {
    ...defaults.shop,
    ...(parsed.shop || {}),
    owned: { ...(parsed.shop?.owned || {}) },
    activeBoosts: { ...defaults.shop.activeBoosts, ...(parsed.shop?.activeBoosts || {}) },
    unlockedCosmetics: { ...(parsed.shop?.unlockedCosmetics || {}) },
    equippedCosmetics: { ...(parsed.shop?.equippedCosmetics || {}) },
  };
  next.achievements = {
    ...defaults.achievements,
    ...(parsed.achievements || {}),
    unlockedAt: { ...(parsed.achievements?.unlockedAt || {}) },
    rewardGranted: { ...(parsed.achievements?.rewardGranted || {}) },
    rewardClaimed: { ...(parsed.achievements?.rewardClaimed || {}) },
  };
  next.reinforcementPool = {
    ...defaults.reinforcementPool,
    ...(parsed.reinforcementPool || {}),
    wordIds: Array.isArray(parsed.reinforcementPool?.wordIds)
      ? parsed.reinforcementPool.wordIds.map((id) => Number(id)).filter(Number.isFinite)
      : [],
  };
  const needsLegacyPowerMigration = parsed.powerBalance == null || parsed.powerAccountingVersion !== POWER_ACCOUNTING_VERSION;
  next.totalPowerSpent = Math.floor(nonNegativeNumber(parsed.totalPowerSpent));
  const grantedRewards = Object.values(next.achievements.rewardGranted).reduce((sum, reward) => sum + nonNegativeNumber(reward), 0);
  const comboRewards = [10, 25, 50].reduce((sum, threshold) => sum + (next.milestones.comboRewards[threshold] ? { 10: 30, 25: 80, 50: 180 }[threshold] : 0), 0);
  const legacyEarned = deriveLegacyPower(parsed) + grantedRewards + comboRewards;
  next.powerBalance = Math.floor(needsLegacyPowerMigration
    ? Math.max(nonNegativeNumber(parsed.powerBalance), legacyEarned - next.totalPowerSpent, 0)
    : nonNegativeNumber(parsed.powerBalance));
  next.totalPowerEarned = Math.max(nonNegativeNumber(parsed.totalPowerEarned), next.powerBalance + next.totalPowerSpent);
  next.powerAccountingVersion = POWER_ACCOUNTING_VERSION;
  next.powerMigrationDone = true;
  next.daily = Object.fromEntries(Object.entries(parsed.daily || {}).map(([date, day]) => {
    const trainingPower = getPower(day);
    return [date, {
      ...day,
      powerCredited: needsLegacyPowerMigration || day.powerCredited == null ? trainingPower : nonNegativeNumber(day.powerCredited),
      powerEarned: needsLegacyPowerMigration ? Math.max(nonNegativeNumber(day.powerEarned), trainingPower) : nonNegativeNumber(day.powerEarned),
    }];
  }));
  const incomingLibrary = parsed.library && typeof parsed.library === "object" ? parsed.library : {};
  next.library = {
    mode: incomingLibrary.mode === "custom" ? "custom" : "builtin",
    builtinWordsetId: incomingLibrary.builtinWordsetId || null,
    customPackage: incomingLibrary.customPackage?.type === WORD_PACKAGE_TYPE ? incomingLibrary.customPackage : null,
    builtinProgress: { ...(incomingLibrary.builtinProgress || {}) },
  };
  if (!parsed.library) next.library.builtinProgress = { ...(parsed.progress || {}) };
  next.progress = { ...(parsed.progress || {}) };
  if (next.library.mode === "custom" && Array.isArray(next.library.customPackage?.words)) {
    next.progress = Object.fromEntries(next.library.customPackage.words.map((item) => [item.id, { ...(item.progress || {}) }]));
  } else {
    next.progress = { ...next.library.builtinProgress, ...next.progress };
    next.library.builtinProgress = { ...next.progress };
  }
  if ((parsed.version || 0) < 2 && (!parsed.settings || parsed.settings.goalMinutes === 240)) next.settings.goalMinutes = 600;
  if ((parsed.version || 0) < 4 && (!parsed.settings || parsed.settings.soundVolume == null || parsed.settings.soundVolume <= 1)) next.settings.soundVolume = 1.6;
  next.sessionsByScope = Object.fromEntries(
    SESSION_SCOPES
      .filter((scope) => parsed.sessionsByScope?.[scope] && typeof parsed.sessionsByScope[scope] === "object")
      .map((scope) => [scope, { ...parsed.sessionsByScope[scope], scope }]),
  );
  const oldSession = parsed.session && typeof parsed.session === "object" ? parsed.session : null;
  const oldScope = oldSession
    ? SESSION_SCOPES.includes(oldSession.scope) ? oldSession.scope : oldSession.kind === "reinforce" ? "reinforce" : "legacy"
    : null;
  if (oldSession && !next.sessionsByScope[oldScope]) next.sessionsByScope[oldScope] = { ...oldSession, scope: oldScope };
  next.activeSessionScope = SESSION_SCOPES.includes(parsed.activeSessionScope) ? parsed.activeSessionScope : oldScope;
  next.session = next.sessionsByScope[next.activeSessionScope] || null;
  next.version = VERSION;
  return next;
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    return normalizeState(JSON.parse(raw));
  } catch (error) {
    console.warn("学习数据读取失败，使用新状态", error);
    return defaultState();
  }
}

function saveState(immediate = false) {
  syncSessionStore();
  syncLibraryPackage();
  state.savedAt = new Date().toISOString();
  const write = () => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      if (session) $("save-status").textContent = "已自动保存";
    } catch (error) {
      console.error(error);
      if (session) $("save-status").textContent = "保存失败";
      showToast("学习数据保存失败，请尽快导出备份");
    }
  };
  if (immediate) {
    clearTimeout(saveHandle);
    write();
    return;
  }
  clearTimeout(saveHandle);
  if (session) $("save-status").textContent = "保存中…";
  saveHandle = setTimeout(write, 80);
}

function getDayStats() {
  const key = todayKey();
  const defaults = { standardRounds: 0, shown: 0, recalls: 0, known: 0, fuzzy: 0, unknown: 0, extras: 0, activeMs: 0, longestStreak: 0, xp: 0, powerEarned: 0, powerCredited: 0, powerSpent: 0, stageCompletions: 0, bestCombo: 0, comboRewards: {}, checkin: false, goalMinutes: state.settings.goalMinutes };
  if (!state.daily[key]) state.daily[key] = defaults;
  const day = state.daily[key];
  Object.entries(defaults).forEach(([field, value]) => { if (day[field] == null) day[field] = value; });
  if (!day.goalMinutes) day.goalMinutes = state.settings.goalMinutes;
  return day;
}

function getProgress(id) {
  const defaults = { familiarity: 0, lastResult: null, known: 0, fuzzy: 0, unknown: 0, reviewCount: 0, lastReactionMs: 0, lastReviewedAt: null, book: "new", dictationCount: 0, dictationCorrectStreak: 0, dictationWrongStreak: 0 };
  let item = state.progress[id];
  if (!item || typeof item !== "object" || Array.isArray(item)) item = {};
  // Readers (including score snapshots) must not detach the record being graded.
  Object.entries(defaults).forEach(([field, value]) => {
    if (!Object.prototype.hasOwnProperty.call(item, field)) item[field] = value;
  });
  state.progress[id] = item;
  return item;
}

function getWordProgress(word) {
  return getProgress(word.id);
}

function syncLibraryPackage() {
  if (!libraryLoaded) return;
  if (!state.library) state.library = { mode: "builtin", customPackage: null, builtinProgress: {} };
  if (state.library.mode === "custom") {
    state.library.customPackage = {
      type: WORD_PACKAGE_TYPE,
      version: WORD_PACKAGE_VERSION,
      words: words.map((word) => ({ ...word, progress: { ...(state.progress[word.id] || {}) } })),
    };
  } else if (state.library.mode === "builtin") {
    state.library.builtinProgress = { ...state.progress };
  }
}

function studyOrderLabel(mode = state.settings.studyOrder) {
  return mode === "familiarity-random" ? "熟度 · 乱序" : "熟度 · 字母";
}

function compareWordsByFamiliarity(a, b) {
  return getWordProgress(a).familiarity - getWordProgress(b).familiarity
    || a.word.localeCompare(b.word, "en", { sensitivity: "base" })
    || Number(a.id) - Number(b.id);
}

function shuffleWords(list) {
  const result = [...list];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

function orderWords(list = words, mode = state.settings.studyOrder) {
  const groups = new Map();
  list.forEach((word) => {
    const familiarity = getWordProgress(word).familiarity;
    if (!groups.has(familiarity)) groups.set(familiarity, []);
    groups.get(familiarity).push(word);
  });
  return [...groups.keys()].sort((a, b) => a - b).flatMap((familiarity) => {
    const group = groups.get(familiarity).sort(compareWordsByFamiliarity);
    return mode === "familiarity-random" ? shuffleWords(group) : group;
  });
}

function buildQueue(list = words, mode = state.settings.studyOrder, base = true) {
  return orderWords(list, mode).map((word) => ({ id: word.id, base }));
}

function reorderQueue(queue, mode = state.settings.studyOrder) {
  const entries = queue
    .map((entry) => ({ entry, word: getWord(entry.id) }))
    .filter((item) => item.word);
  const orderedWords = orderWords(entries.map((item) => item.word), mode);
  const entriesById = new Map(entries.map((item) => [String(item.entry.id), item.entry]));
  return orderedWords.map((word) => entriesById.get(String(word.id))).filter(Boolean);
}

function getWord(id) {
  return words.find((item) => item.id === id || String(item.id) === String(id));
}

function normalizeWordList(list) {
  return list.map((item) => ({ id: Number(item.id), word: String(item.word).trim(), meaning: String(item.meaning).trim() }));
}

function normalizeProgressRecord(record = {}) {
  if (!record || typeof record !== "object") record = {};
  const tested = nonNegativeNumber(record.dictationCount) > 0 && ["weak", "mastered"].includes(record.book);
  const book = tested ? record.book : "new";
  return {
    familiarity: Math.max(0, Math.min(100, Number(record.familiarity) || 0)),
    lastResult: ["known", "fuzzy", "unknown"].includes(record.lastResult) ? record.lastResult : null,
    known: Math.max(0, Number(record.known) || 0),
    fuzzy: Math.max(0, Number(record.fuzzy) || 0),
    unknown: Math.max(0, Number(record.unknown) || 0),
    reviewCount: Math.max(0, Number(record.reviewCount) || 0),
    lastReactionMs: Math.max(0, Number(record.lastReactionMs) || 0),
    lastReviewedAt: record.lastReviewedAt || null,
    book,
    dictationCount: tested ? Math.floor(nonNegativeNumber(record.dictationCount)) : 0,
    dictationCorrectStreak: book === "weak" ? Math.min(9, Math.floor(nonNegativeNumber(record.dictationCorrectStreak))) : 0,
    dictationWrongStreak: book === "mastered" ? Math.min(1, Math.floor(nonNegativeNumber(record.dictationWrongStreak))) : 0,
  };
}

function validateBookProgress(record) {
  if (!record || typeof record !== "object" || Array.isArray(record)) throw new Error("单词学习记录格式不正确");
  if (record.book != null && !BOOK_SCOPES.includes(record.book)) throw new Error("单词词本归属不正确");
  ["dictationCount", "dictationCorrectStreak", "dictationWrongStreak"].forEach((field) => {
    if (record[field] != null && (!Number.isInteger(record[field]) || record[field] < 0)) throw new Error(`单词 ${field} 必须是非负整数`);
  });
  if (record.book === "weak" && record.dictationCorrectStreak >= 10) throw new Error("生词连续正确次数超出范围");
  if (record.book === "mastered" && record.dictationWrongStreak >= 2) throw new Error("熟词连续错误次数超出范围");
}

function makeWordPackage(list = words, progress = state.progress) {
  return {
    type: WORD_PACKAGE_TYPE,
    version: WORD_PACKAGE_VERSION,
    exportedAt: new Date().toISOString(),
    words: list.map((word) => ({ ...word, progress: normalizeProgressRecord(progress[word.id] || progress[String(word.id)] || {}) })),
  };
}

function validateWordPackage(payload) {
  if (!payload || payload.type !== WORD_PACKAGE_TYPE || payload.version !== WORD_PACKAGE_VERSION) throw new Error("不是有效的词表包");
  if (!Array.isArray(payload.words) || payload.words.length === 0) throw new Error("词表不能为空");
  const ids = new Set();
  const normalized = payload.words.map((item) => {
    const id = Number(item.id);
    const word = String(item.word || "").trim();
    const meaning = String(item.meaning || "").trim();
    if (!Number.isFinite(id) || !word || !meaning) throw new Error("词条缺少单词、释义或有效 ID");
    if (ids.has(id)) throw new Error(`发现重复词条 ID：${id}`);
    ids.add(id);
    if (item.progress != null) validateBookProgress(item.progress);
    return { id, word, meaning, progress: normalizeProgressRecord(item.progress || {}) };
  });
  return { type: WORD_PACKAGE_TYPE, version: WORD_PACKAGE_VERSION, exportedAt: payload.exportedAt || new Date().toISOString(), words: normalized };
}

function activateBuiltinWords() {
  state.library.mode = "builtin";
  state.library.builtinWordsetId = BUILTIN_WORDSET_ID;
  words = builtinWords.map((word) => ({ ...word }));
  const activeIds = new Set(words.map((word) => String(word.id)));
  state.progress = Object.fromEntries(
    Object.entries(state.library.builtinProgress || {})
      .filter(([id]) => activeIds.has(String(id)))
      .map(([id, record]) => [id, normalizeProgressRecord(record)]),
  );
  state.library.builtinProgress = { ...state.progress };
  selectedWordIds.clear();
}

function activateCustomPackage(wordPackage) {
  state.library.mode = "custom";
  state.library.customPackage = wordPackage;
  words = wordPackage.words.map(({ id, word, meaning }) => ({ id, word, meaning }));
  state.progress = Object.fromEntries(wordPackage.words.map((item) => [item.id, normalizeProgressRecord(item.progress)]));
  selectedWordIds.clear();
}

function syncSessionStore() {
  if (!state.sessionsByScope) state.sessionsByScope = {};
  const active = session || state.session;
  if (!active || !SESSION_SCOPES.includes(active.scope)) return;
  state.sessionsByScope[active.scope] = active;
  state.activeSessionScope = active.scope;
  state.session = active;
}

function normalizeSessionRecord(saved, scope) {
  const reinforcement = scope === "reinforce";
  const activeIds = new Set(words.map((word) => String(word.id)));
  const rawQueue = Array.isArray(saved.queue) ? saved.queue : [];
  const validQueue = rawQueue.filter((entry) => entry && (reinforcement || entry.base !== false));
  const rawSeen = Object.keys(saved.baseSeen || {}).filter((id) => saved.baseSeen[id]);
  const rawIds = Array.isArray(saved.scopeWordIds)
    ? saved.scopeWordIds
    : [...rawSeen, ...(saved.current ? [saved.current.id] : []), ...validQueue.map((entry) => entry.id)];
  const scopeWordIds = [...new Set(rawIds.map(Number))].filter((id) => activeIds.has(String(id)));
  const scopeIds = new Set(scopeWordIds.map(String));
  const baseSeen = Object.fromEntries(rawSeen.filter((id) => scopeIds.has(String(id))).map((id) => [id, true]));
  const legacyReinforceSeenCount = reinforcement
    ? Array.isArray(saved.scopeWordIds) ? nonNegativeNumber(saved.legacyReinforceSeenCount) : nonNegativeNumber(saved.reinforceSeenCount)
    : 0;
  const current = saved.current && scopeIds.has(String(saved.current.id))
    && (!baseSeen[saved.current.id] || saved.dictationSubmitted)
    ? { id: Number(saved.current.id), base: !reinforcement }
    : null;
  const queuedIds = new Set();
  const queue = validQueue.filter((entry) => {
    const key = String(entry.id);
    if (!scopeIds.has(key) || baseSeen[key] || queuedIds.has(key) || (current && key === String(current.id))) return false;
    queuedIds.add(key);
    return true;
  }).map((entry) => ({ id: Number(entry.id), base: !reinforcement }));
  const staleExtras = reinforcement ? [] : rawQueue.filter((entry) => entry?.base === false && activeIds.has(String(entry.id))).map((entry) => Number(entry.id));
  if (staleExtras.length && !state.reinforcementPool.wordIds.length) {
    state.reinforcementPool = { wordIds: [...new Set(staleExtras)], sourceRound: getDayStats().standardRounds, createdAt: new Date().toISOString() };
  }
  return {
    ...saved,
    scope,
    kind: reinforcement ? "reinforce" : "base",
    scopeWordIds,
    totalCount: scopeWordIds.length + legacyReinforceSeenCount,
    orderMode: STUDY_ORDER_MODES.includes(saved.orderMode) ? saved.orderMode : state.settings.studyOrder,
    studyMode: STUDY_MODES.includes(saved.studyMode) ? saved.studyMode : "recall",
    baseSeen,
    baseSeenCount: Object.keys(baseSeen).length,
    legacyReinforceSeenCount,
    reinforceSeenCount: reinforcement ? Object.keys(baseSeen).length + legacyReinforceSeenCount : 0,
    weakIds: [...new Set((saved.weakIds || []).map(Number))].filter((id) => scopeIds.has(String(id))),
    queue,
    current,
    finishedBase: Boolean(saved.finishedBase),
    dictationSubmitted: Boolean(current && saved.dictationSubmitted),
    dictationResult: current && saved.dictationSubmitted ? saved.dictationResult : null,
    dictationInput: current && typeof saved.dictationInput === "string" ? saved.dictationInput : "",
    answerShown: Boolean(current && saved.answerShown),
    bookFeedback: current && typeof saved.bookFeedback === "string" ? saved.bookFeedback : "",
    dictationOverridden: Boolean(current && saved.dictationOverridden),
    dictationRollback: current && validDictationRollback(saved.dictationRollback) ? saved.dictationRollback : null,
    dictationBookOverride: current && saved.dictationSubmitted && ["weak", "mastered"].includes(saved.dictationBookOverride) ? saved.dictationBookOverride : null,
  };
}

function normalizeSavedSession() {
  syncSessionStore();
  state.sessionsByScope = Object.fromEntries(
    Object.entries(state.sessionsByScope || {})
      .filter(([scope, saved]) => SESSION_SCOPES.includes(scope) && saved && typeof saved === "object")
      .map(([scope, saved]) => [scope, normalizeSessionRecord(saved, scope)])
      .filter(([, saved]) => saved.totalCount > 0),
  );
  state.session = state.sessionsByScope[state.activeSessionScope] || null;
  if (!state.session) state.activeSessionScope = null;
}

function recoverSavedDictationProgress() {
  return ProgressRecovery.recover(state, words.map((word) => word.id));
}

function suspendStudy() {
  if (session) {
    tickStudyTime();
    saveState(true);
    clearTimeout(session.revealTimer);
  }
  clearInterval(timerHandle);
  clearTimeout(nextCardHandle);
  session = null;
}

function hasResumableSession(scope = state.activeSessionScope) {
  const saved = state.sessionsByScope?.[scope];
  return Boolean(saved && (saved.current || saved.queue?.length || saved.totalCount > 0));
}

function mostRecentSessionScope() {
  if (hasResumableSession()) return state.activeSessionScope;
  return Object.keys(state.sessionsByScope || {})
    .filter((scope) => hasResumableSession(scope))
    .sort((first, second) => (state.sessionsByScope[second].lastActivatedAt || state.sessionsByScope[second].startedAt || 0)
      - (state.sessionsByScope[first].lastActivatedAt || state.sessionsByScope[first].startedAt || 0))[0] || null;
}

function resumeLastSession() {
  const scope = mostRecentSessionScope();
  if (scope) startSession(true, scope);
  else {
    updateHome();
    showScreen("home");
    showToast("请选择新词、生词或熟词开始训练");
  }
}

function clearStudySessionForLibraryChange() {
  const wasStudying = Boolean(session) || document.body.classList.contains("study-mode");
  clearInterval(timerHandle);
  clearTimeout(nextCardHandle);
  clearTimeout(session?.revealTimer);
  session = null;
  state.session = null;
  state.sessionsByScope = {};
  state.activeSessionScope = null;
  const activeIds = new Set(words.map((word) => String(word.id)));
  state.reinforcementPool = {
    ...(state.reinforcementPool || { sourceRound: 0, createdAt: null }),
    wordIds: (state.reinforcementPool?.wordIds || []).filter((id) => activeIds.has(String(id))),
  };
  if (wasStudying) showScreen("home");
}

function confirmLibraryMutation(action) {
  if (!mostRecentSessionScope() && !session) return true;
  return window.confirm(`当前还有未完成的学习轮。${action}后会清空所有词本的未完成队列，但历史学习时间、成就和熟识度会保留。继续吗？`);
}

function libraryMutationNotice() {
  return mostRecentSessionScope() || session ? "\n未完成的轮次会保留，只跳过被删词，不会重开。" : "";
}

function getLibraryFilteredWords() {
  const query = librarySearch.trim().toLowerCase();
  const range = libraryFamiliarityFilter === "all" ? null : libraryFamiliarityFilter.split("-").map(Number);
  return words
    .filter((word) => {
      const item = getWordProgress(word);
      const matchesQuery = !query || word.word.toLowerCase().includes(query) || word.meaning.toLowerCase().includes(query);
      const matchesRange = !range || (item.familiarity >= range[0] && item.familiarity <= range[1]);
      const matchesBook = libraryBookFilter === "all" || item.book === libraryBookFilter;
      return matchesQuery && matchesRange && matchesBook;
    })
    .sort((a, b) => getWordProgress(a).familiarity - getWordProgress(b).familiarity || a.word.localeCompare(b.word, "en"));
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
}

function closeWordEditor() {
  editingWordId = null;
  $("word-edit-modal").classList.add("hidden");
}

function openWordEditor(id) {
  const word = getWord(id);
  if (!word) return;
  const item = getWordProgress(word);
  editingWordId = Number(word.id);
  $("word-edit-word").textContent = word.word;
  $("word-edit-meaning").value = word.meaning;
  const bookSelect = $("word-edit-book");
  bookSelect.innerHTML = item.book === "new"
    ? '<option value="new">新词本（待首次默写）</option>'
    : '<option value="weak">生词本</option><option value="mastered">熟词本</option>';
  bookSelect.value = item.book;
  bookSelect.disabled = item.book === "new";
  $("word-edit-book-note").textContent = item.book === "new"
    ? "新词须先完成首次默写，不能手动修改词本归属。"
    : "生词与熟词可互换；换本清零连续对/错次数，保留熟识度、历史记录和未完成轮次。";
  $("word-edit-modal").classList.remove("hidden");
  window.setTimeout(() => {
    $("word-edit-meaning").focus();
    $("word-edit-meaning").select();
  }, 0);
}

function refreshCurrentWordMeaning(id) {
  if (!session?.current || String(session.current.id) !== String(id)) return;
  const word = getWord(id);
  if (!word) return;
  $("meaning-text").textContent = word.meaning;
}

function saveWordEdits() {
  if (editingWordId == null) return;
  const word = getWord(editingWordId);
  if (!word) {
    closeWordEditor();
    return;
  }
  const meaning = $("word-edit-meaning").value.trim();
  if (!meaning) {
    showToast("中文释义不能为空");
    $("word-edit-meaning").focus();
    return;
  }
  const item = getWordProgress(word);
  const book = $("word-edit-book").value;
  const meaningChanged = meaning !== word.meaning;
  const bookChanged = book !== item.book;
  if (bookChanged && (!["weak", "mastered"].includes(item.book) || item.dictationCount <= 0 || !["weak", "mastered"].includes(book))) {
    showToast("仅支持生词与熟词互换，新词不能手动修改归属");
    $("word-edit-book").focus();
    return;
  }
  if (!meaningChanged && !bookChanged) {
    closeWordEditor();
    showToast("单词属性没有变化");
    return;
  }
  if (meaningChanged) {
    if (state.library.mode === "builtin") {
      state.library.builtinProgress = { ...state.progress };
      state.library.mode = "custom";
    }
    word.meaning = meaning;
    refreshCurrentWordMeaning(word.id);
  }
  if (bookChanged) {
    item.book = book;
    item.dictationCorrectStreak = 0;
    item.dictationWrongStreak = 0;
    // A later verdict replay must not restore the book from before this edit.
    new Set([session, state.session, ...Object.values(state.sessionsByScope || {})]).forEach((saved) => {
      if (!saved?.dictationSubmitted || String(saved.current?.id) !== String(word.id)) return;
      saved.dictationBookOverride = book;
      saved.bookFeedback = `词本已手动改为${bookLabel(book)}`;
    });
    updateStudyMeta();
  }
  saveState(true);
  updateHome();
  renderLibrary();
  closeWordEditor();
  showToast(bookChanged ? `“${word.word}”已改为${bookLabel(book)}${meaningChanged ? "，释义已更新" : ""}` : `“${word.word}”释义已更新，立即生效`);
}

function libraryResultLabel(result) {
  return result === "known" ? "认识" : result === "fuzzy" ? "模糊" : result === "unknown" ? "不认识" : "未判断";
}

function renderLibrary() {
  if (!$("library-screen")) return;
  const total = words.length;
  const progressItems = words.map((word) => getWordProgress(word));
  const studied = progressItems.filter((item) => item.reviewCount > 0).length;
  const average = total ? Math.round(progressItems.reduce((sum, item) => sum + item.familiarity, 0) / total) : 0;
  const unfamiliar = progressItems.filter((item) => item.familiarity < 40).length;
  $("library-source").textContent = state.library.mode === "custom" ? "自定义词表" : "内置词库";
  $("library-total-count").textContent = total;
  $("library-studied-count").textContent = studied;
  $("library-average").textContent = average;
  $("library-unfamiliar-count").textContent = unfamiliar;
  $("restore-builtin-button").hidden = state.library.mode === "builtin";
  $("restore-builtin-button").disabled = state.library.mode === "builtin";
  $("restore-custom-button").hidden = state.library.mode !== "builtin" || !state.library.customPackage?.words?.length;
  const counts = getBookCounts();
  $("library-book-count-all").textContent = total;
  BOOK_SCOPES.forEach((scope) => { $(`library-book-count-${scope}`).textContent = counts[scope]; });
  document.querySelectorAll("[data-library-book]").forEach((button) => {
    const active = button.dataset.libraryBook === libraryBookFilter;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  updateLibraryStudyTools();
  filteredLibraryWords = getLibraryFilteredWords();
  selectedWordIds = new Set([...selectedWordIds].filter((id) => words.some((word) => String(word.id) === String(id))));
  $("library-result-count").textContent = `${filteredLibraryWords.length} 个词`;
  renderLibraryList();
  updateLibrarySelectionUI();
  syncLibraryRail();
}

function renderLibraryList() {
  const scroll = $("word-list-scroll");
  const content = $("word-list-content");
  if (!scroll || !content) return;
  const viewportHeight = Math.max(scroll.clientHeight, 300);
  const start = Math.max(0, Math.floor(scroll.scrollTop / WORD_ROW_HEIGHT) - VIRTUAL_OVERSCAN);
  const visibleCount = Math.ceil(viewportHeight / WORD_ROW_HEIGHT) + VIRTUAL_OVERSCAN * 2;
  const end = Math.min(filteredLibraryWords.length, start + visibleCount);
  const top = start * WORD_ROW_HEIGHT;
  const bottom = Math.max(LIBRARY_BOTTOM_GUTTER, (filteredLibraryWords.length - end) * WORD_ROW_HEIGHT + LIBRARY_BOTTOM_GUTTER);
  const rows = filteredLibraryWords.slice(start, end).map((word) => {
    const item = getWordProgress(word);
    const checked = selectedWordIds.has(String(word.id));
    const familiarity = Math.round(item.familiarity);
    return `<article class="word-row ${checked ? "selected" : ""}" style="height:${WORD_ROW_HEIGHT}px"><label class="word-row-select"><input type="checkbox" data-word-action="select" data-id="${word.id}" ${checked ? "checked" : ""} aria-label="选择 ${escapeHtml(word.word)}" /></label><div class="word-row-main"><div class="word-row-title"><strong>${escapeHtml(word.word)}</strong><span class="word-book-badge book-${item.book}">${bookLabel(item.book)}</span></div><p title="${escapeHtml(word.meaning)}">${escapeHtml(word.meaning)}</p><div class="word-row-status"><span>${wordBookStatus(item)}</span><span>熟识度 ${familiarity}</span></div><div class="word-row-progress"><span style="width:${familiarity}%"></span></div></div><div class="word-row-meta"><span>${item.reviewCount} 次复习</span><span>${libraryResultLabel(item.lastResult)}</span></div><div class="word-row-actions"><button class="word-edit-button" type="button" data-word-action="edit" data-id="${word.id}" aria-label="编辑 ${escapeHtml(word.word)} 的属性" title="编辑释义与词本归属"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m4 16-.8 4.8L8 20l11.5-11.5a2.1 2.1 0 0 0-3-3L4 16Z"/><path d="m14.5 7.5 2 2"/></svg></button><button class="word-delete-button" type="button" data-word-action="delete" data-id="${word.id}" aria-label="删除 ${escapeHtml(word.word)}" title="删除此词"><svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M6 7l1 13h10l1-13M9 7l1-3h4l1 3"/></svg></button></div></article>`;
  }).join("");
  content.style.height = `${filteredLibraryWords.length * WORD_ROW_HEIGHT + LIBRARY_BOTTOM_GUTTER}px`;
  content.innerHTML = `<div style="height:${top}px"></div>${rows}<div style="height:${bottom}px"></div>`;
}

function updateLibrarySelectionUI() {
  const visibleIds = filteredLibraryWords.map((word) => String(word.id));
  const selectedVisible = visibleIds.filter((id) => selectedWordIds.has(id)).length;
  $("selected-word-count").textContent = selectedWordIds.size;
  $("delete-selected-words").disabled = selectedWordIds.size === 0;
  const selectAll = $("select-visible-words");
  selectAll.checked = visibleIds.length > 0 && selectedVisible === visibleIds.length;
  selectAll.indeterminate = selectedVisible > 0 && selectedVisible < visibleIds.length;
}

function syncLibraryRail() {
  const scroll = $("word-list-scroll");
  const thumb = $("word-list-thumb");
  const track = $("word-list-track");
  if (!scroll || !thumb || !track) return;
  const max = Math.max(0, scroll.scrollHeight - scroll.clientHeight);
  const ratio = max ? scroll.scrollTop / max : 0;
  const thumbHeight = Math.max(32, Math.min(track.clientHeight, track.clientHeight * scroll.clientHeight / Math.max(scroll.scrollHeight, scroll.clientHeight)));
  thumb.style.height = `${thumbHeight}px`;
  thumb.style.transform = `translateY(${(track.clientHeight - thumbHeight) * ratio}px)`;
  thumb.disabled = max === 0;
}

function setLibraryScrollRatio(ratio) {
  const scroll = $("word-list-scroll");
  if (!scroll) return;
  const max = Math.max(0, scroll.scrollHeight - scroll.clientHeight);
  scroll.scrollTop = Math.max(0, Math.min(1, ratio)) * max;
  syncLibraryRail();
  renderLibraryList();
}

function removeWordIds(ids, mutationConfirmed = false) {
  const idSet = new Set(ids.map(String).filter((id) => getWord(id)));
  if (!idSet.size || (!mutationConfirmed && !window.confirm(`确定删除 ${idSet.size} 个词及对应学习记录吗？${libraryMutationNotice()}`))) return false;
  const wasStudying = Boolean(session);
  const deletedCurrent = session?.current && idSet.has(String(session.current.id));
  syncSessionStore();
  if (deletedCurrent) {
    clearTimeout(session.revealTimer);
    clearTimeout(nextCardHandle);
  }
  const remaining = words.filter((word) => !idSet.has(String(word.id)));
  if (state.library.mode === "builtin") {
    state.library.builtinProgress = Object.fromEntries(Object.entries(state.progress).filter(([id]) => !idSet.has(String(id))));
    state.library.mode = "custom";
    state.library.customPackage = makeWordPackage(remaining, state.progress);
  }
  words = remaining;
  state.progress = Object.fromEntries(remaining.map((word) => [word.id, normalizeProgressRecord(state.progress[word.id] || state.progress[String(word.id)] || {})]));
  if (state.library.mode === "custom") state.library.customPackage = makeWordPackage(words, state.progress);
  state.reinforcementPool.wordIds = state.reinforcementPool.wordIds.filter((id) => !idSet.has(String(id)));
  normalizeSavedSession();
  if (wasStudying) {
    session = state.session;
    if (!session) {
      clearInterval(timerHandle);
      showScreen("home");
    } else if (deletedCurrent) {
      loadNextCard();
    } else {
      updateStudyMeta();
    }
  }
  selectedWordIds = new Set([...selectedWordIds].filter((id) => !idSet.has(String(id))));
  saveState(true);
  updateHome();
  renderLibrary();
  showToast(`已删除 ${idSet.size} 个词，其他词的轮次和进度已保留`);
  return true;
}

function handleLibraryListClick(event) {
  const actionTarget = event.target.closest("[data-word-action]");
  if (!actionTarget) return;
  const id = actionTarget.dataset.id;
  if (actionTarget.dataset.wordAction === "edit") {
    openWordEditor(id);
    return;
  }
  if (actionTarget.dataset.wordAction === "delete") {
    const word = getWord(id);
    if (word && window.confirm(`确定删除“${word.word}”吗？该词的熟识度记录也会一起删除。${libraryMutationNotice()}`)) removeWordIds([id], true);
  }
}

function handleLibraryListChange(event) {
  const checkbox = event.target.closest('input[data-word-action="select"]');
  if (!checkbox) return;
  const id = String(checkbox.dataset.id);
  if (checkbox.checked) selectedWordIds.add(id);
  else selectedWordIds.delete(id);
  renderLibraryList();
  updateLibrarySelectionUI();
}

function selectVisibleLibraryWords() {
  const selectAll = $("select-visible-words");
  const visibleIds = filteredLibraryWords.map((word) => String(word.id));
  if (selectAll.checked) visibleIds.forEach((id) => selectedWordIds.add(id));
  else visibleIds.forEach((id) => selectedWordIds.delete(id));
  renderLibraryList();
  updateLibrarySelectionUI();
}

function exportWordList() {
  const payload = makeWordPackage();
  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: "application/json;charset=utf-8" });
  fallbackExport(blob, json, `全量背词助手-词表-${todayKey()}.json`, "词表已导出");
}

function importWordList(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const wordPackage = validateWordPackage(JSON.parse(reader.result));
      if (!confirmLibraryMutation("导入词表")) return;
      if (state.library.mode === "builtin") state.library.builtinProgress = { ...state.progress };
      activateCustomPackage(wordPackage);
      clearStudySessionForLibraryChange();
      saveState(true);
      updateHome();
      renderLibrary();
      showToast(`已导入 ${words.length} 个词，学习队列已重建`);
    } catch (error) {
      showToast(`导入词表失败：${error.message || "文件格式不正确"}`);
    } finally {
      $("word-import-file").value = "";
    }
  };
  reader.onerror = () => showToast("导入词表失败：无法读取文件");
  reader.readAsText(file);
}

function restoreBuiltinWords() {
  if (state.library.mode === "builtin") return;
  if (!confirmLibraryMutation("恢复内置词库")) return;
  activateBuiltinWords();
  clearStudySessionForLibraryChange();
  saveState(true);
  updateHome();
  renderLibrary();
  showToast(`已恢复内置词库，共 ${words.length} 个词`);
}

function restoreCustomWords() {
  if (state.library.mode === "custom" || !state.library.customPackage?.words) return;
  if (!confirmLibraryMutation("切回自定义词表")) return;
  const wordPackage = { ...state.library.customPackage, words: state.library.customPackage.words.map((item) => ({ ...item, progress: normalizeProgressRecord(item.progress) })) };
  activateCustomPackage(wordPackage);
  clearStudySessionForLibraryChange();
  saveState(true);
  updateHome();
  renderLibrary();
  showToast(`已切回自定义词表，共 ${words.length} 个词`);
}

function formatMinutes(ms) {
  const minutes = Math.floor(ms / 60000);
  if (minutes < 60) return `${minutes} 分钟`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return `${hours} 小时${rest ? ` ${rest} 分钟` : ""}`;
}

function formatClock(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function getLevel(xp) {
  return Math.max(1, Math.floor(xp / 250) + 1);
}

function getPower(day) {
  return Math.floor(nonNegativeNumber(day.xp) + nonNegativeNumber(day.activeMs) / 60000 * 2 + nonNegativeNumber(day.standardRounds) * 120 + nonNegativeNumber(day.known) * 2);
}

function getFamiliarityAverage() {
  if (!words.length) return 0;
  const total = words.reduce((sum, word) => sum + getProgress(word.id).familiarity, 0);
  return Math.round(total / words.length);
}

function awardPower(amount, reason = "", day = getDayStats()) {
  const gain = Math.max(0, Math.floor(Number(amount) || 0));
  if (!gain) return 0;
  state.powerBalance = Math.max(0, (state.powerBalance || 0) + gain);
  state.totalPowerEarned = (state.totalPowerEarned || 0) + gain;
  day.powerEarned = (day.powerEarned || 0) + gain;
  return gain;
}

function syncTrainingPower(day = getDayStats()) {
  const trainingPower = getPower(day);
  const gain = Math.max(0, trainingPower - nonNegativeNumber(day.powerCredited));
  day.powerCredited = Math.max(trainingPower, nonNegativeNumber(day.powerCredited));
  return awardPower(gain, "学习", day);
}

function spendPower(amount, day = getDayStats()) {
  const cost = Math.max(0, Math.floor(Number(amount) || 0));
  if (!cost || (state.powerBalance || 0) < cost) return false;
  state.powerBalance -= cost;
  state.totalPowerSpent = (state.totalPowerSpent || 0) + cost;
  day.powerSpent = (day.powerSpent || 0) + cost;
  return true;
}

function getActiveBoostLabel() {
  const boosts = state.shop.activeBoosts;
  const labels = [];
  if (boosts.doubleXpRemaining > 0) labels.push(`双倍 XP ${boosts.doubleXpRemaining}`);
  if (boosts.comboCharm > 0) labels.push("连击护符待命");
  if (boosts.stageBonusRemaining > 0) labels.push(`阶段保险 ${boosts.stageBonusRemaining}`);
  if (boosts.unknownShield > 0) labels.push(`低谷护盾 ${boosts.unknownShield}`);
  if (boosts.extraReliefRemaining > 0) labels.push(`加练减负 ${boosts.extraReliefRemaining}`);
  return labels.join(" · ") || "暂无激活增益";
}

function getStagePercent() {
  if (!session) return 0;
  return Math.min(100, Math.round(((session.stageProgress || 0) / 20) * 100));
}

function getReinforcementWords() {
  const ids = new Set((state.reinforcementPool?.wordIds || []).map((id) => String(id)));
  return words.filter((word) => ids.has(String(word.id)));
}

function getAchievementStats() {
  const days = Object.values(state.daily || {});
  const activeMs = days.reduce((sum, day) => sum + (day.activeMs || 0), 0);
  const recalls = days.reduce((sum, day) => sum + (day.recalls || 0), 0);
  const rounds = days.reduce((sum, day) => sum + (day.standardRounds || 0), 0);
  const checkins = days.filter((day) => isDayChecked(day)).length;
  const bestPower = days.reduce((best, day) => Math.max(best, getPower(day)), 0);
  const stageCompletions = days.reduce((sum, day) => sum + (day.stageCompletions || 0), 0);
  return { activeMs, recalls, rounds, checkins, currentStreak: getCheckinStreak(), bestCombo: state.bestCombo || 0, bestPower, xp: state.totalXp || 0, stageCompletions, familiarityAverage: getFamiliarityAverage(), shopUnlocks: Object.keys(state.shop?.owned || {}).length, powerSpent: state.totalPowerSpent || 0 };
}

function syncAchievementRewards(announce = false) {
  const stats = getAchievementStats();
  let changed = false;
  let unlockedCount = 0;
  let powerReward = 0;
  ACHIEVEMENTS.forEach((achievement) => {
    if (!state.achievements.unlockedAt[achievement.id] && !achievement.test(stats)) return;
    if (!state.achievements.unlockedAt[achievement.id]) {
      state.achievements.unlockedAt[achievement.id] = new Date().toISOString();
      changed = true;
    }
    if (state.achievements.rewardGranted[achievement.id]) return;
    const reward = achievement.reward || 0;
    powerReward += awardPower(reward);
    state.achievements.rewardGranted[achievement.id] = reward;
    state.achievements.rewardClaimed[achievement.id] = true;
    unlockedCount += 1;
    changed = true;
  });
  if (changed) saveState(true);
  if (announce && unlockedCount) {
    playFeedbackSound("checkin", true);
    showToast(`成就达成 ×${unlockedCount} · 奖励已到账 +${powerReward} 战力`);
  }
  return changed;
}

function getMonthDays(year, month) {
  const first = new Date(year, month, 1, 12);
  const daysInMonth = new Date(year, month + 1, 0, 12).getDate();
  const leadingBlanks = (first.getDay() + 6) % 7;
  const days = Array.from({ length: daysInMonth }, (_, index) => {
    const date = new Date(year, month, index + 1, 12);
    const key = `${year}-${String(month + 1).padStart(2, "0")}-${String(index + 1).padStart(2, "0")}`;
    return { key, date, stats: state.daily?.[key] || null };
  });
  return { name: `${year}年${month + 1}月`, leadingBlanks, days };
}

function renderCalendarMonth() {
  const monthData = getMonthDays(calendarYear, calendarMonth);
  const today = todayKey();
  const checkedCount = monthData.days.filter((item) => isDayChecked(item.stats)).length;
  $("calendar-year-label").textContent = monthData.name;
  $("calendar-count").textContent = `${checkedCount} 天达成`;
  const cells = [...Array(monthData.leadingBlanks).fill(null), ...monthData.days].map((item) => {
      if (!item) return `<span class="year-day blank"></span>`;
      const minutes = Math.floor((item.stats?.activeMs || 0) / 60000);
      const goalMinutes = item.stats?.goalMinutes || state.settings.goalMinutes;
      const ratio = goalMinutes ? minutes / goalMinutes : 0;
      const level = minutes >= goalMinutes ? 3 : ratio >= .5 ? 2 : minutes > 0 ? 1 : 0;
      const checked = isDayChecked(item.stats);
      const isToday = item.key === today;
      return `<span class="year-day level-${level} ${checked ? "checked" : ""} ${isToday ? "today" : ""}" title="${item.key} · ${minutes} 分钟${checked ? " · 已达成目标" : ""}"><small>${item.date.getDate()}</small>${checked ? "<i>✓</i>" : ""}</span>`;
  }).join("");
  $("year-calendar").innerHTML = `<section class="month-card"><div class="month-week"><span>一</span><span>二</span><span>三</span><span>四</span><span>五</span><span>六</span><span>日</span></div><div class="month-grid">${cells}</div></section>`;
}

function isDayChecked(day) {
  return Boolean(day?.checkin || (day && day.checkin === undefined && (day.activeMs || 0) >= (day.goalMinutes || state.settings.goalMinutes) * 60000));
}

function getCheckinStreak() {
  const checked = new Set(Object.entries(state.daily || {}).filter(([, day]) => isDayChecked(day)).map(([key]) => key));
  let cursor = new Date();
  cursor.setHours(12, 0, 0, 0);
  let today = `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, "0")}-${String(cursor.getDate()).padStart(2, "0")}`;
  if (!checked.has(today)) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (true) {
    const key = `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, "0")}-${String(cursor.getDate()).padStart(2, "0")}`;
    if (!checked.has(key)) break;
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

function syncCheckin(day) {
  const targetMs = (day.goalMinutes || state.settings.goalMinutes) * 60000;
  if (day.checkin || day.activeMs < targetMs) return false;
  day.checkin = true;
  day.checkinAt = new Date().toISOString();
  day.xp = (day.xp || 0) + 100;
  state.totalXp = (state.totalXp || 0) + 100;
  syncTrainingPower(day);
  state.streak = getCheckinStreak();
  playFeedbackSound("checkin", true);
  showToast("今日打卡成功！十小时目标达成 · +100 XP · +100 战力");
  syncAchievementRewards(true);
  saveState(true);
  return true;
}

function badgeSvg(id, unlocked) {
  const palette = unlocked ? { a: "#c6973f", b: "#f7d98a", c: "#fff7dc" } : { a: "#a8afbf", b: "#dfe2eb", c: "#f5f6fa" };
  const shapes = {
    start: `<path d="M32 13 36.5 25h12.8l-10.2 7.6L43 45.5 32 38l-11 7.5 3.9-12.9L14.7 25h12.8L32 13Z"/>`,
    hundred: `<circle cx="32" cy="32" r="13"/><circle cx="32" cy="32" r="19"/><path d="M24 32h16M32 24v16"/>`,
    round: `<path d="m32 12 14 5v11c0 10-5.7 16.4-14 22-8.3-5.6-14-12-14-22V17l14-5Z"/><path d="m25 32 5 5 10-11"/>`,
    "three-rounds": `<circle cx="32" cy="32" r="19"/><path d="M32 18v14l9 6"/><path d="M22 16a20 20 0 0 0-8 16M42 16a20 20 0 0 1 8 16"/>`,
    hour: `<circle cx="32" cy="32" r="18"/><path d="M32 21v12l8 5"/><path d="M25 9h14"/>`,
    "ten-hours": `<circle cx="32" cy="32" r="10"/><path d="M32 7v7M32 43v7M7 32h7M43 32h7M14.3 14.3l5 5M36.7 36.7l5 5M41.7 14.3l-5 5M19.3 36.7l-5 5"/>`,
    "three-days": `<rect x="16" y="18" width="32" height="29" rx="5"/><path d="M22 13v9M42 13v9M16 27h32M23 34h5M32 34h5M23 40h5M32 40h5"/>`,
    "seven-days": `<path d="M32 12c7 8 11 12 11 20a11 11 0 1 1-22 0c0-5 3-9 7-13 1.7-1.7 3-3.7 4-7Z"/><path d="M32 27c3 3 4 5 4 8a4 4 0 1 1-8 0c0-2 1-4 4-8Z"/>`,
    combo: `<path d="m35 8-16 19h10l-3 19 16-23H32l3-15Z"/>`,
    power: `<path d="m32 11 4.5 8.5 9.5 1.4-7 6.8 1.7 9.6-8.7-4.5-8.7 4.5 1.7-9.6-7-6.8 9.5-1.4L32 11Z"/><path d="M20 43h24M24 47h16"/>`,
    xp: `<path d="m32 11 17 10v19L32 50 15 40V21l17-10Z"/><path d="m25 25 7 14 7-14M28 31h8"/>`,
    century: `<path d="M14 32c0-6 5-10 10-10s8 4 8 10-3 10-8 10-10-4-10-10ZM42 32c0-6 3-10 8-10s10 4 10 10-5 10-10 10-8-4-8-10Z" transform="translate(-9 0)"/><path d="M20 32h24"/>`,
  }[id] || `<circle cx="32" cy="32" r="16"/>`;
  return `<svg class="badge-art" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="badge-${id}" x1="8" y1="8" x2="56" y2="56"><stop stop-color="${palette.b}"/><stop offset="1" stop-color="${palette.a}"/></linearGradient></defs><circle cx="32" cy="32" r="27" fill="${palette.c}" stroke="${palette.b}" stroke-width="2"/><circle cx="32" cy="32" r="22" fill="url(#badge-${id})" opacity=".2"/><g fill="none" stroke="${palette.a}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5">${shapes}</g></svg>`;
}

function renderAchievements() {
  const stats = getAchievementStats();
  if (libraryLoaded) syncAchievementRewards(false);
  const unlocked = ACHIEVEMENTS.filter((item) => state.achievements.unlockedAt[item.id]);
  const collectionPercent = Math.round((unlocked.length / ACHIEVEMENTS.length) * 100);
  const rewardPower = Object.values(state.achievements.rewardGranted || {}).reduce((sum, value) => sum + (Number(value) || 0), 0);
  const rewardCount = Object.keys(state.achievements.rewardGranted || {}).length;
  $("achievement-unlocked").textContent = unlocked.length;
  $("achievement-total").textContent = `/ ${ACHIEVEMENTS.length} 枚徽章`;
  $("achievement-percent").textContent = `${collectionPercent}%`;
  $("collection-ring").style.setProperty("--collection-progress", `${collectionPercent}%`);
  $("achievement-streak").textContent = stats.currentStreak;
  $("achievement-hours").textContent = (stats.activeMs / 3600000).toFixed(stats.activeMs >= 3600000 ? 1 : 2);
  $("achievement-reward-power").textContent = rewardPower;
  $("achievement-reward-count").textContent = rewardCount;
  const next = ACHIEVEMENTS.find((item) => !state.achievements.unlockedAt[item.id]);
  $("achievement-next").textContent = next ? `下一枚：${next.title}` : "全部收藏完成";
  $("badge-grid").innerHTML = ACHIEVEMENTS.map((item, index) => {
    const isUnlocked = Boolean(state.achievements.unlockedAt[item.id]);
    const rarity = index < 8 ? "common" : index < 16 ? "rare" : "legendary";
    const rarityLabel = rarity === "common" ? "常规" : rarity === "rare" ? "稀有" : "传说";
    const granted = Boolean(state.achievements.rewardGranted[item.id]);
    return `<article class="badge-item ${isUnlocked ? "unlocked" : "locked"} rarity-${rarity}"><div class="badge-icon">${badgeSvg(item.id, isUnlocked)}</div><div><strong>${item.title}</strong><span>${item.description}</span><small class="badge-reward">+${item.reward} 战力</small></div><b>${granted ? "奖励已到账" : isUnlocked ? "即将到账" : "未解锁"}</b><em>${rarityLabel}</em></article>`;
  }).join("");
  renderCalendarMonth();
}

function renderProfile() {
  window.AppReader?.renderRecords();
  const stats = getAchievementStats();
  const today = getDayStats();
  $("profile-level").textContent = `Lv.${getLevel(state.totalXp || 0)}`;
  $("profile-xp").textContent = `${state.totalXp || 0} XP`;
  $("profile-power").textContent = state.powerBalance || 0;
  $("profile-power-balance").textContent = state.powerBalance || 0;
  $("profile-combo").textContent = `×${state.bestCombo || 0}`;
  $("profile-rounds").textContent = stats.rounds;
  $("profile-recalls").textContent = stats.recalls;
  $("profile-caption").textContent = today.activeMs > 0 ? `今天已经投入 ${formatMinutes(today.activeMs)}，继续把这条线拉长。` : "今天还没有开战，先完成第一个 20 词阶段。";
  document.querySelectorAll(".theme-option").forEach((button) => button.classList.toggle("active", button.dataset.theme === (state.settings.theme || "aurora")));
  $("shop-active-line").textContent = getActiveBoostLabel();
  renderShop();
}

function renderShop() {
  const grid = $("shop-grid");
  if (!grid) return;
  const balance = state.powerBalance || 0;
  grid.innerHTML = SHOP_ITEMS.map((item) => {
    const owned = state.shop.owned[item.id] || 0;
    const unlocked = Boolean(state.shop.unlockedCosmetics[item.id]);
    const equipped = Boolean(state.shop.equippedCosmetics[item.id]);
    const active = item.id === "double-xp" || item.id === "double-xp-large" ? state.shop.activeBoosts.doubleXpRemaining : item.id === "combo-charm" || item.id === "combo-charm-pack" ? state.shop.activeBoosts.comboCharm : item.id === "extra-relief" || item.id === "extra-relief-large" ? state.shop.activeBoosts.extraReliefRemaining : item.id === "stage-insurance" ? state.shop.activeBoosts.stageBonusRemaining : item.id === "focus-shield" ? state.shop.activeBoosts.unknownShield : 0;
    const isCosmetic = item.type === "cosmetic";
    const canAfford = balance >= item.price;
    const status = isCosmetic ? (unlocked ? (equipped ? "已装备" : "已解锁") : `还差 ${Math.max(0, item.price - balance)} 战力`) : (active ? `剩余 ${active}${item.id === "combo-charm" ? " 次" : " 次"}` : owned ? `已兑换 ${owned} 次` : "尚未兑换");
    const action = isCosmetic && unlocked ? "toggle" : "buy";
    const label = isCosmetic && unlocked ? (equipped ? "卸下" : "装备") : canAfford ? "兑换" : "战力不足";
    return `<article class="shop-item ${unlocked || active ? "shop-item-active" : ""}"><div class="shop-item-icon">${item.icon}</div><div class="shop-item-copy"><strong>${item.title}</strong><span>${item.description}</span><small>${status}</small></div><div class="shop-item-action"><b>${item.price}</b><button type="button" data-shop-action="${action}" data-shop-id="${item.id}" ${action === "buy" && !canAfford ? "disabled" : ""}>${label}</button></div></article>`;
  }).join("");
  document.body.classList.toggle("cosmetic-ochre-seal", Boolean(state.shop.equippedCosmetics["ochre-seal"]));
  document.body.classList.toggle("cosmetic-vermillion-seal", Boolean(state.shop.equippedCosmetics["vermillion-seal"]));
  document.body.classList.toggle("cosmetic-jade-seal", Boolean(state.shop.equippedCosmetics["jade-seal"]));
  document.body.classList.toggle("cosmetic-collection-frame", Boolean(state.shop.equippedCosmetics["collection-frame"]));
  document.body.classList.toggle("cosmetic-gold-frame", Boolean(state.shop.equippedCosmetics["gold-frame"]));
  document.body.classList.toggle("cosmetic-full-runner", Boolean(state.shop.equippedCosmetics["full-runner"]));
  document.body.classList.toggle("cosmetic-scholar-title", Boolean(state.shop.equippedCosmetics["scholar-title"]));
}

function purchaseShopItem(id) {
  const item = SHOP_ITEMS.find((candidate) => candidate.id === id);
  if (!item) return;
  if (item.type === "cosmetic" && state.shop.unlockedCosmetics[id]) {
    state.shop.equippedCosmetics[id] = !state.shop.equippedCosmetics[id];
    saveState(true);
    renderProfile();
    showToast(`${item.title}${state.shop.equippedCosmetics[id] ? "已装备" : "已卸下"}`);
    return;
  }
  if ((state.powerBalance || 0) < item.price) {
    showToast(`战力不足，还差 ${item.price - (state.powerBalance || 0)} 战力`);
    return;
  }
  if (!spendPower(item.price)) return;
  state.shop.owned[id] = (state.shop.owned[id] || 0) + 1;
  if (id === "double-xp") state.shop.activeBoosts.doubleXpRemaining += 20;
  if (id === "double-xp-large") state.shop.activeBoosts.doubleXpRemaining += 100;
  if (id === "combo-charm") state.shop.activeBoosts.comboCharm += 1;
  if (id === "combo-charm-pack") state.shop.activeBoosts.comboCharm += 5;
  if (id === "extra-relief") state.shop.activeBoosts.extraReliefRemaining += 10;
  if (id === "extra-relief-large") state.shop.activeBoosts.extraReliefRemaining += 50;
  if (id === "stage-insurance") state.shop.activeBoosts.stageBonusRemaining += 3;
  if (id === "focus-shield") state.shop.activeBoosts.unknownShield += 10;
  if (item.type === "cosmetic") {
    state.shop.unlockedCosmetics[id] = true;
    state.shop.equippedCosmetics[id] = true;
  }
  saveState(true);
  syncAchievementRewards(true);
  updateHome();
  renderProfile();
  showToast(`${item.title}已${item.type === "cosmetic" ? "解锁并装备" : "激活"} · 剩余 ${state.powerBalance} 战力`);
}

function setTheme(theme) {
  state.settings.theme = theme;
  document.body.dataset.theme = theme;
  document.querySelectorAll(".theme-option").forEach((button) => button.classList.toggle("active", button.dataset.theme === theme));
  saveState(true);
  showToast(`已切换为「${document.querySelector(`.theme-option[data-theme="${theme}"] strong`)?.textContent || "新皮肤"}」`);
}

function switchAchievementPanel(panel) {
  document.querySelectorAll(".achievement-tab").forEach((button) => button.classList.toggle("active", button.dataset.panel === panel));
  document.querySelectorAll(".achievement-panel").forEach((item) => item.classList.toggle("active", item.id === `${panel}-panel`));
}

function showScreen(name) {
  if (name !== "reader") window.AppReader?.leave();
  Object.values(screens).forEach((screen) => screen.classList.remove("active"));
  if (!screens[name]) name = "home";
  screens[name].classList.add("active");
  document.body.classList.toggle("study-mode", name === "study");
  document.body.classList.toggle("reading-mode", name === "reader");
  if (name !== "study") document.body.classList.remove("dictation-mode");
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.screen === name));
  if (name === "achievements") renderAchievements();
  if (name === "library") renderLibrary();
  if (name === "profile") renderProfile();
  if (name === "reader") window.AppReader?.enter();
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastHandle);
  toastHandle = setTimeout(() => toast.classList.remove("show"), 2200);
}

function getAudioContext() {
  if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
  if (audioContext.state === "suspended") audioContext.resume().catch(() => {});
  return audioContext;
}

function getAudioBus() {
  const context = getAudioContext();
  if (!audioBus) {
    const compressor = context.createDynamicsCompressor();
    compressor.threshold.setValueAtTime(-18, context.currentTime);
    compressor.knee.setValueAtTime(12, context.currentTime);
    compressor.ratio.setValueAtTime(12, context.currentTime);
    compressor.attack.setValueAtTime(0.003, context.currentTime);
    compressor.release.setValueAtTime(0.18, context.currentTime);
    const masterGain = context.createGain();
    masterGain.gain.setValueAtTime(1.45, context.currentTime);
    masterGain.connect(compressor).connect(context.destination);
    audioBus = { masterGain };
  }
  return audioBus;
}

function playTone(frequency, duration = 0.12, delay = 0, wave = "sine", gainValue = 0.28) {
  if (!state.settings.sound) return;
  try {
    const context = getAudioContext();
    const bus = getAudioBus();
    const start = context.currentTime + delay;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = wave;
    oscillator.frequency.setValueAtTime(frequency, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(Math.min(0.7, gainValue * (state.settings.soundVolume ?? 1.6)), start + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    oscillator.connect(gain).connect(bus.masterGain);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.02);
  } catch (error) {
    console.debug("音效不可用", error);
  }
}

function playImpactNoise(delay = 0, duration = 0.08) {
  if (!state.settings.sound) return;
  try {
    const context = getAudioContext();
    const bus = getAudioBus();
    const start = context.currentTime + delay;
    const buffer = context.createBuffer(1, Math.floor(context.sampleRate * duration), context.sampleRate);
    const data = buffer.getChannelData(0);
    for (let index = 0; index < data.length; index += 1) data[index] = (Math.random() * 2 - 1) * (1 - index / data.length);
    const source = context.createBufferSource();
    const filter = context.createBiquadFilter();
    const gain = context.createGain();
    filter.type = "highpass";
    filter.frequency.setValueAtTime(900, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(Math.min(0.35, 0.22 * (state.settings.soundVolume ?? 1.6)), start + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    source.buffer = buffer;
    source.connect(filter).connect(gain).connect(bus.masterGain);
    source.start(start);
  } catch (error) {
    console.debug("冲击音效不可用", error);
  }
}

function buzz(pattern) {
  if (navigator.vibrate) navigator.vibrate(pattern);
}

function playFeedbackSound(type, milestone = false) {
  if (!state.settings.sound) return;
  const sounds = {
    known: [[620, 0], [820, 0.07]],
    fuzzy: [[470, 0]],
    unknown: [[230, 0], [170, 0.08]],
    reveal: [[360, 0]],
    checkin: [[720, 0], [920, 0.1], [1200, 0.2]],
  };
  const wave = type === "unknown" ? "sawtooth" : type === "known" || type === "checkin" ? "triangle" : "sine";
  (sounds[type] || sounds.reveal).forEach(([frequency, delay]) => playTone(frequency, 0.16, delay, wave, type === "unknown" ? 0.24 : 0.34));
  if (type === "known" || type === "checkin") playImpactNoise(0.02, 0.09);
  if (type === "known") buzz(10);
  if (type === "fuzzy") buzz(7);
  if (type === "unknown") buzz([14, 18, 14]);
  if (milestone) {
    [[660, 0], [830, 0.09], [1040, 0.18]].forEach(([frequency, delay]) => playTone(frequency, 0.24, delay, "triangle", 0.4));
    playImpactNoise(0.04, 0.12);
    buzz([18, 28, 18, 28, 48]);
  }
}

function updateHome() {
  if (libraryLoaded) {
    syncTrainingPower();
    syncAchievementRewards(false);
  }
  const day = getDayStats();
  const total = words.length;
  const latestScope = mostRecentSessionScope();
  const saved = latestScope ? state.sessionsByScope[latestScope] : null;
  const current = saved?.kind === "reinforce" ? saved.reinforceSeenCount : saved?.baseSeenCount || 0;
  const activeStudyMode = saved && STUDY_MODES.includes(saved.studyMode) ? saved.studyMode : state.settings.studyMode;
  const reinforcementCount = getReinforcementWords().length;
  const goalMs = state.settings.goalMinutes * 60000;
  const percentage = Math.min(100, Math.round((day.activeMs / goalMs) * 100));
  const power = state.powerBalance || 0;
  const level = getLevel(state.totalXp || 0);
  $("library-pill").textContent = total ? `${total} 个词 · ${state.library.mode === "custom" ? "自定义词表" : "内置词库"}` : "词库加载失败";
  $("home-study-mode").textContent = saved ? `续学 · ${studyModeLabel(activeStudyMode)}` : studyModeLabel(activeStudyMode);
  $("hero-rounds").textContent = day.standardRounds;
  $("home-power").textContent = power;
  $("home-level").textContent = `Lv.${level}`;
  $("home-xp").textContent = `${state.totalXp || 0} XP`;
  $("home-power-balance").textContent = `${state.powerBalance || 0}`;
  $("home-power-earned").textContent = `今日新增 ${day.powerEarned || 0}`;
  const nextShopItem = SHOP_ITEMS.find((item) => !(state.shop.owned[item.id] || state.shop.unlockedCosmetics[item.id]));
  const nextCost = nextShopItem ? Math.max(0, nextShopItem.price - (state.powerBalance || 0)) : 0;
  $("home-next-shop").textContent = nextShopItem ? (nextCost ? `距「${nextShopItem.title}」还差 ${nextCost}` : `可兑换「${nextShopItem.title}」`) : "商店藏品已收齐";
  $("home-power-progress").style.width = `${nextShopItem ? Math.min(100, Math.round(((state.powerBalance || 0) / nextShopItem.price) * 100)) : 100}%`;
  $("home-time").textContent = formatMinutes(day.activeMs);
  $("home-time-goal").textContent = `目标 ${state.settings.goalMinutes} 分钟`;
  $("home-coverage").textContent = saved ? `${current} / ${saved.totalCount}` : "待选择";
  $("home-coverage-scope").textContent = saved ? `${bookLabel(latestScope)} · 当前轮进度` : "三个词本分别续学";
  $("home-extra").textContent = reinforcementCount;
  $("home-streak").textContent = `${state.streak} 天`;
  $("home-total-time").textContent = `累计 ${formatMinutes(state.totalActiveMs)}`;
  $("daily-progress-bar").style.width = `${percentage}%`;
  $("daily-progress-text").textContent = `${percentage}%`;
  $("daily-recalls").textContent = `${day.recalls} 次`;
  $("daily-extras").textContent = `${day.extras} 次`;
  $("daily-badge").textContent = day.checkin ? "今日已打卡" : `${percentage}% 目标`;
  $("home-mission-percent").textContent = `${percentage}%`;
  $("home-mission-progress").style.width = `${percentage}%`;
  $("home-mission-time").textContent = `${formatMinutes(day.activeMs)} / ${formatMinutes(goalMs)}`;
  const filledSegments = Math.min(10, Math.floor(percentage / 10));
  $("mission-segments").innerHTML = Array.from({ length: 10 }, (_, index) => `<span class="${index < filledSegments ? "filled" : ""}"></span>`).join("");
  const counts = getBookCounts();
  BOOK_SCOPES.forEach((scope) => {
    const resumable = hasResumableSession(scope);
    const button = $(`book-start-${scope}`);
    const stored = state.sessionsByScope[scope];
    button.disabled = !libraryLoaded || (!counts[scope] && !resumable);
    button.classList.toggle("has-session", resumable);
    $(`book-count-${scope}`).textContent = counts[scope];
    $(`book-action-${scope}`).textContent = resumable
      ? `继续 · ${(scope === "reinforce" ? stored.reinforceSeenCount : stored.baseSeenCount)} / ${stored.totalCount}`
      : counts[scope] ? scope === "new" ? "开始首次测验" : "开始词本全量" : `暂无${{ new: "新词", weak: "生词", mastered: "熟词" }[scope]}`;
  });
  $("book-training-hint").textContent = state.settings.studyMode === "dictation"
    ? "首次默写分流 · 生词连对 10 次晋级 · 熟词连错 2 次回炉"
    : "当前为看词练习，不改变词本；在设置中切换中文默写进行分流。";
  updateLibraryStudyTools();
  renderAchievements();
  renderProfile();
}

function updateLibraryStudyTools() {
  const count = getReinforcementWords().length;
  const saved = state.sessionsByScope.reinforce;
  $("reinforce-button").disabled = !count && !hasResumableSession("reinforce");
  $("reinforce-button").textContent = hasResumableSession("reinforce")
    ? `继续加练 · ${saved.reinforceSeenCount} / ${saved.totalCount}`
    : count ? `本轮重点加练 · ${count} 个词` : "暂无重点词可加练";
  $("legacy-session-button").hidden = !hasResumableSession("legacy");
  $("library-tools-status").textContent = hasResumableSession("legacy") ? "有旧版全量轮可续学" : count ? `${count} 个重点词可加练` : "加练不打断词本全量";
}

function getScopeWords(scope) {
  if (scope === "reinforce") return getReinforcementWords();
  if (scope === "legacy") return words;
  return words.filter((word) => getWordProgress(word).book === scope);
}

function createSession(scope = "new", studyWords = getScopeWords(scope)) {
  const reinforcement = scope === "reinforce";
  const orderMode = state.settings.studyOrder;
  return {
    scope,
    kind: reinforcement ? "reinforce" : "base",
    scopeWordIds: studyWords.map((word) => word.id),
    orderMode,
    studyMode: STUDY_MODES.includes(state.settings.studyMode) ? state.settings.studyMode : "recall",
    totalCount: studyWords.length,
    queue: buildQueue(studyWords, orderMode, !reinforcement),
    baseSeen: {},
    baseSeenCount: 0,
    reinforceSeenCount: 0,
    weakIds: [],
    current: null,
    answerShown: false,
    extraCount: 0,
    startedAt: Date.now(),
    activeMs: 0,
    streak: 0,
    combo: 0,
    bestCombo: 0,
    stageProgress: 0,
    stageReward: 0,
    xp: 0,
    finishedBase: false,
    dictationSubmitted: false,
    dictationResult: null,
    dictationInput: "",
    dictationOverridden: false,
    dictationRollback: null,
    dictationBookOverride: null,
    bookFeedback: "",
    sourcePoolCreatedAt: reinforcement ? state.reinforcementPool.createdAt : null,
  };
}

function startSession(resume = true, scope = "new") {
  if (!SESSION_SCOPES.includes(scope)) return;
  suspendStudy();
  if (!resume || !hasResumableSession(scope)) {
    const studyWords = getScopeWords(scope);
    if (!studyWords.length) {
      updateHome();
      showScreen("home");
      showToast(`${bookLabel(scope)}暂无可训练的词`);
      return;
    }
    state.sessionsByScope[scope] = createSession(scope, studyWords);
  }
  state.activeSessionScope = scope;
  session = state.sessionsByScope[scope];
  state.session = session;
  session.lastActivatedAt = Date.now();
  session.kind = session.kind === "reinforce" ? "reinforce" : "base";
  session.orderMode = STUDY_ORDER_MODES.includes(session.orderMode) ? session.orderMode : state.settings.studyOrder;
  session.studyMode = STUDY_MODES.includes(session.studyMode) ? session.studyMode : "recall";
  session.streak = session.streak || 0;
  session.combo = session.combo || 0;
  session.bestCombo = session.bestCombo || 0;
  session.stageProgress = session.stageProgress || 0;
  session.stageReward = session.stageReward || 0;
  session.xp = session.xp || 0;
  session.answerShown = Boolean(session.answerShown);
  session.dictationSubmitted = Boolean(session.dictationSubmitted);
  session.dictationResult = ["known", "unknown"].includes(session.dictationResult) ? session.dictationResult : null;
  session.dictationInput = typeof session.dictationInput === "string" ? session.dictationInput : "";
  session.baseSeen = session.baseSeen || {};
  session.queue = Array.isArray(session.queue) ? session.queue : [];
  session.startedAt = session.startedAt || Date.now();
  session.lastTick = performance.now();
  session.lastActivity = performance.now();
  $("pause-study").textContent = session.paused ? "继续" : "暂停";
  $("word-card").style.opacity = session.paused ? "0.62" : "1";
  showScreen("study");
  if (session.current && getWord(session.current.id)) {
    session.cardStartedAt = performance.now();
    renderCurrentCard();
  } else {
    loadNextCard();
  }
  if (!session) return;
  clearInterval(timerHandle);
  timerHandle = setInterval(tickStudyTime, 1000);
  saveState(true);
  updateStudyMeta();
}

function startReinforcementSession() {
  if (!getReinforcementWords().length && !hasResumableSession("reinforce")) {
    showToast("本轮还没有需要加练的词");
    return;
  }
  startSession(true, "reinforce");
}

function toggleStudyOrder() {
  const nextMode = state.settings.studyOrder === "familiarity-random" ? "familiarity-alpha" : "familiarity-random";
  state.settings.studyOrder = nextMode;
  if (session) {
    session.orderMode = nextMode;
    session.queue = reorderQueue(session.queue, nextMode);
  }
  updateStudyMeta();
  saveState(true);
  showToast(`已切换为${studyOrderLabel(nextMode)}，剩余词已重排`);
}

function tickStudyTime() {
  if (!session || session.paused) return;
  const now = performance.now();
  const delta = now - (session.lastTick || now);
  session.lastTick = now;
  const inactive = now - (session.lastActivity || now) > 30000;
  if (document.hidden || inactive) return;
  session.activeMs += delta;
  const day = getDayStats();
  day.activeMs += delta;
  state.totalActiveMs += delta;
  syncTrainingPower(day);
  const checkinJustCompleted = syncCheckin(day);
  updateStudyMeta();
  if (checkinJustCompleted) {
    updateHome();
    renderAchievements();
    renderProfile();
  }
  if (!session.lastSaveAt || now - session.lastSaveAt > 10000) {
    session.lastSaveAt = now;
    saveState();
  }
}

function registerActivity() {
  if (!session) return;
  session.lastActivity = performance.now();
  if (session.paused) return;
  if (!session.lastTick) session.lastTick = performance.now();
}

function loadNextCard() {
  if (!session) return;
  if (!session.queue.length) {
    finishSession();
    return;
  }
  session.current = session.queue.shift();
  session.answerShown = false;
  session.dictationSubmitted = false;
  session.dictationResult = null;
  session.dictationInput = "";
  session.dictationOverridden = false;
  session.dictationRollback = null;
  session.dictationBookOverride = null;
  session.bookFeedback = "";
  renderCurrentCard();
}

function renderCurrentCard() {
  const word = getWord(session.current.id);
  if (!word) return loadNextCard();
  const isBase = session.kind !== "reinforce";
  const isDictation = session.studyMode === "dictation";
  const seenCount = isBase ? session.baseSeenCount : session.reinforceSeenCount;
  const totalCount = session.totalCount;
  session.cardStartedAt = performance.now();
  session.lastActivity = performance.now();
  document.body.classList.toggle("dictation-mode", isDictation);
  screens.study.classList.toggle("dictation-layout", isDictation);
  $("word-card").classList.remove("card-enter");
  void $("word-card").offsetWidth;
  $("word-card").classList.add("card-enter");
  $("word-text").textContent = word.word;
  if (isDictation) {
    const dictationWordSize = Math.max(44, Math.min(104, 700 / Math.max(word.word.length * 0.72, 1)));
    $("word-text").style.setProperty("--dictation-word-size", `${dictationWordSize}px`);
  } else {
    $("word-text").style.removeProperty("--dictation-word-size");
  }
  $("meaning-text").textContent = word.meaning;
  $("meaning-box").classList.toggle("hidden", isDictation ? !session.dictationSubmitted : !session.answerShown);
  $("answer-buttons").classList.toggle("hidden", isDictation || !session.answerShown);
  $("reveal-button").classList.toggle("hidden", isDictation || session.answerShown);
  $("dictation-box").classList.toggle("hidden", !isDictation);
  $("feedback-message").textContent = isDictation
    ? session.dictationSubmitted
      ? session.dictationResult === "known" ? "释义正确！再按 Enter 进入下一词" : "核心释义有遗漏或错误 · 再按 Enter 进入下一词"
      : "输入完整中文释义后按 Enter 提交"
    : session.answerShown
      ? "做出判断：认识、模糊，还是不认识？"
      : isBase ? "先在心里提取，再看释义" : "手动加练：再把它提取一次";
  $("impact-pop").classList.remove("pop");
  const cardNumber = Math.min(totalCount, seenCount + (session.dictationSubmitted ? 0 : 1));
  $("card-index").textContent = `${bookLabel(session.scope)} · ${isDictation ? "默写" : "提取"} ${cardNumber} / ${totalCount}`;
  if (isDictation) {
    const input = $("dictation-input");
    const submit = $("dictation-submit");
    input.value = session.dictationInput || "";
    input.disabled = Boolean(session.dictationSubmitted);
    submit.textContent = session.dictationSubmitted ? "下一词 · Enter" : "提交答案 · Enter";
    $("dictation-hint").textContent = dictationResultHint();
    window.setTimeout(() => {
      if (!session || session.studyMode !== "dictation") return;
      (session.dictationSubmitted ? submit : input).focus();
    }, 0);
  }
  if (isDictation && session.dictationSubmitted) renderDictationSubmitted();
  syncDictationOverrideButton();
  const seconds = Number(state.settings.revealSeconds);
  if (!isDictation && !session.answerShown && seconds > 0) {
    clearTimeout(session.revealTimer);
    session.revealTimer = setTimeout(showAnswer, seconds * 1000);
  }
  updateStudyMeta();
}

function renderDictationSubmitted() {
  if (!session || session.studyMode !== "dictation") return;
  session.answerShown = true;
  $("meaning-box").classList.remove("hidden");
  $("dictation-input").disabled = true;
  $("dictation-submit").textContent = "下一词 · Enter";
  $("dictation-hint").textContent = dictationResultHint();
  $("feedback-message").textContent = session.dictationResult === "known"
    ? `${session.bookFeedback || "释义正确！"} · 再按 Enter 进入下一词`
    : `${session.bookFeedback || "核心释义有遗漏或错误"} · 再按 Enter 进入下一词`;
  updateStudyMeta();
  syncDictationOverrideButton();
  $("dictation-submit").focus({ preventScroll: true });
}

function cloneData(value) {
  return JSON.parse(JSON.stringify(value));
}

function validDictationRollback(value) {
  return Boolean(value && value.before && value.after && value.before.item && value.before.day && value.before.session && ["known", "unknown"].includes(value.originalResult));
}

function captureScoreSnapshot(id) {
  const day = getDayStats();
  return {
    id: Number(id),
    dayKey: todayKey(),
    item: cloneData(getProgress(id)),
    day: {
      shown: day.shown || 0,
      recalls: day.recalls || 0,
      known: day.known || 0,
      fuzzy: day.fuzzy || 0,
      unknown: day.unknown || 0,
      extras: day.extras || 0,
      xp: day.xp || 0,
      bestCombo: day.bestCombo || 0,
      stageCompletions: day.stageCompletions || 0,
      standardRounds: day.standardRounds || 0,
      powerEarned: day.powerEarned || 0,
      powerCredited: day.powerCredited || 0,
    },
    session: {
      xp: session.xp || 0,
      combo: session.combo || 0,
      bestCombo: session.bestCombo || 0,
      streak: session.streak || 0,
      stageProgress: session.stageProgress || 0,
      stageReward: session.stageReward || 0,
      weakIds: [...(session.weakIds || [])],
      baseSeen: { ...(session.baseSeen || {}) },
      baseSeenCount: session.baseSeenCount || 0,
      reinforceSeenCount: session.reinforceSeenCount || 0,
      extraCount: session.extraCount || 0,
      finishedBase: Boolean(session.finishedBase),
    },
    totalXp: state.totalXp || 0,
    bestCombo: state.bestCombo || 0,
    powerBalance: state.powerBalance || 0,
    totalPowerEarned: state.totalPowerEarned || 0,
    activeBoosts: cloneData(state.shop.activeBoosts),
    comboRewards: cloneData(state.milestones.comboRewards || {}),
    achievements: cloneData(state.achievements),
    reinforcementPool: cloneData(state.reinforcementPool),
  };
}

function restoreAchievementMap(before, after, current) {
  const next = { ...(current || {}) };
  const keys = new Set([...Object.keys(before || {}), ...Object.keys(after || {})]);
  keys.forEach((key) => {
    if (JSON.stringify(before?.[key]) === JSON.stringify(after?.[key])) return;
    if (before?.[key] === undefined) delete next[key];
    else next[key] = cloneData(before[key]);
  });
  return next;
}

function restoreScoreSnapshot(before, after) {
  state.progress[before.id] = cloneData(before.item);
  const day = state.daily?.[before.dayKey];
  if (day) {
    ["shown", "recalls", "known", "fuzzy", "unknown", "extras", "xp", "bestCombo", "stageCompletions", "standardRounds", "powerEarned", "powerCredited"].forEach((key) => {
      const delta = (after.day?.[key] || 0) - (before.day?.[key] || 0);
      day[key] = Math.max(0, (day[key] || 0) - delta);
    });
  }
  const previous = before.session;
  session.xp = previous.xp;
  session.combo = previous.combo;
  session.bestCombo = previous.bestCombo;
  session.streak = previous.streak;
  session.stageProgress = previous.stageProgress;
  session.stageReward = previous.stageReward;
  session.weakIds = [...(previous.weakIds || [])];
  session.baseSeen = { ...(previous.baseSeen || {}) };
  session.baseSeenCount = previous.baseSeenCount;
  session.reinforceSeenCount = previous.reinforceSeenCount;
  session.extraCount = previous.extraCount;
  session.finishedBase = previous.finishedBase;
  state.totalXp = Math.max(0, (before.totalXp || 0) + ((state.totalXp || 0) - (after.totalXp || 0)));
  state.bestCombo = before.bestCombo || 0;
  state.powerBalance = Math.max(0, (before.powerBalance || 0) + ((state.powerBalance || 0) - (after.powerBalance || 0)));
  state.totalPowerEarned = Math.max(0, (before.totalPowerEarned || 0) + ((state.totalPowerEarned || 0) - (after.totalPowerEarned || 0)));
  state.shop.activeBoosts = { ...state.shop.activeBoosts, ...cloneData(before.activeBoosts || {}) };
  state.milestones.comboRewards = cloneData(before.comboRewards || {});
  state.achievements = {
    ...state.achievements,
    unlockedAt: restoreAchievementMap(before.achievements?.unlockedAt, after.achievements?.unlockedAt, state.achievements.unlockedAt),
    rewardGranted: restoreAchievementMap(before.achievements?.rewardGranted, after.achievements?.rewardGranted, state.achievements.rewardGranted),
    rewardClaimed: restoreAchievementMap(before.achievements?.rewardClaimed, after.achievements?.rewardClaimed, state.achievements.rewardClaimed),
  };
  state.reinforcementPool = cloneData(before.reinforcementPool);
}

function dictationResultHint() {
  if (!session?.dictationSubmitted) return "可省略使役的“使”和修饰的“的/地”，词组可换序";
  if (session.dictationOverridden && session.dictationResult === "known") return "已手动改判为正确";
  return session.dictationResult === "known" ? "已通过核心释义匹配" : "核心释义未匹配，已记为不认识";
}

function syncDictationOverrideButton() {
  const button = $("dictation-override");
  if (!button) return;
  const canUndo = Boolean(session?.dictationOverridden && session.dictationResult === "known" && validDictationRollback(session.dictationRollback));
  const show = Boolean(session && session.studyMode === "dictation" && session.dictationSubmitted && session.current && (session.dictationResult === "unknown" || canUndo));
  button.classList.toggle("hidden", !show);
  if (show) button.textContent = session.dictationResult === "unknown" ? "改判为对" : "撤销改判";
}

function toggleDictationVerdict() {
  if (!session || session.paused || session.studyMode !== "dictation" || !session.dictationSubmitted || !session.current) return;
  const rollback = session.dictationRollback;
  if (validDictationRollback(rollback)) {
    if (rollback.before.dayKey && rollback.before.dayKey !== todayKey()) {
      showToast("已经跨天，这条不能再改判");
      return;
    }
    const next = session.dictationResult === "unknown" ? "known" : rollback.originalResult;
    if (next === session.dictationResult || !["known", "unknown"].includes(next)) return;
    restoreScoreSnapshot(rollback.before, rollback.after);
    session.dictationSubmitted = false;
    session.dictationResult = null;
    answer(next, { deferNext: true, dictationText: session.dictationInput || "", replaying: true });
    showToast(next === "known" ? "已改判为正确" : "已撤销改判");
    return;
  }
  if (session.dictationResult === "unknown") fallbackOverrideDictation();
}

function applyDictationBookOverride(item) {
  if (!["weak", "mastered"].includes(session?.dictationBookOverride)) return;
  item.book = session.dictationBookOverride;
  item.dictationCorrectStreak = 0;
  item.dictationWrongStreak = 0;
  session.bookFeedback = `词本已手动改为${bookLabel(item.book)}`;
}

function fallbackOverrideDictation() {
  const item = getProgress(session.current.id);
  const day = getDayStats();
  const feedback = session.bookFeedback || "";
  if (feedback.startsWith("首测未通过") && item.book === "weak") {
    item.book = "mastered";
    item.dictationCorrectStreak = 0;
    item.dictationWrongStreak = 0;
    session.bookFeedback = "首测通过 · 已进入熟词本";
  } else if (feedback.startsWith("连续错 2 次") && item.book === "weak") {
    item.book = "mastered";
    item.dictationCorrectStreak = 0;
    item.dictationWrongStreak = 0;
    session.bookFeedback = "熟词保持 · 已通过";
  } else if (feedback.startsWith("熟词连续错误") && item.book === "mastered") {
    item.dictationWrongStreak = 0;
    session.bookFeedback = "熟词保持 · 已通过";
  } else if (feedback.startsWith("仍在生词本") && item.book === "weak") {
    item.dictationCorrectStreak = Math.min(9, (item.dictationCorrectStreak || 0) + 1);
    session.bookFeedback = `生词连续正确 ${item.dictationCorrectStreak} / 10`;
  } else {
    session.bookFeedback = "已手动改判为正确";
  }
  applyDictationBookOverride(item);
  if (item.unknown > 0) item.unknown -= 1;
  item.known += 1;
  item.lastResult = "known";
  item.familiarity = Math.max(0, Math.min(100, (item.familiarity || 0) + 9));
  if (day.unknown > 0) day.unknown -= 1;
  day.known = (day.known || 0) + 1;
  const xpDelta = 8;
  day.xp = (day.xp || 0) + xpDelta;
  state.totalXp = (state.totalXp || 0) + xpDelta;
  session.xp = (session.xp || 0) + xpDelta;
  session.combo = (session.combo || 0) + 1;
  session.streak = (session.streak || 0) + 1;
  session.bestCombo = Math.max(session.bestCombo || 0, session.combo);
  day.bestCombo = Math.max(day.bestCombo || 0, session.combo);
  state.bestCombo = Math.max(state.bestCombo || 0, session.bestCombo);
  session.weakIds = (session.weakIds || []).filter((wordId) => String(wordId) !== String(session.current.id));
  if (session.finishedBase) {
    state.reinforcementPool = {
      ...(state.reinforcementPool || {}),
      wordIds: [...new Set((session.weakIds || []).filter((wordId) => getWord(wordId)))],
    };
  }
  [10, 25, 50].forEach((threshold) => {
    if (session.combo >= threshold && !state.milestones.comboRewards[threshold]) {
      const reward = { 10: 30, 25: 80, 50: 180 }[threshold];
      state.milestones.comboRewards[threshold] = true;
      awardPower(reward, `${threshold} 连击`, day);
    }
  });
  const powerGain = syncTrainingPower(day);
  session.dictationResult = "known";
  session.dictationOverridden = true;
  applyFeedback("known", { xpGain: xpDelta, powerGain });
  syncAchievementRewards(true);
  saveState(true);
  updateHome();
  renderDictationSubmitted();
  showToast("已改判为正确");
}

function submitDictation() {
  if (!session || session.paused || session.studyMode !== "dictation" || !session.current) return;
  if (session.dictationSubmitted) {
    advanceDictation();
    return;
  }
  const word = getWord(session.current.id);
  if (!word) return;
  const typed = $("dictation-input").value;
  const correct = DictationGrader.matches(typed, word.meaning);
  answer(correct ? "known" : "unknown", { deferNext: true, dictationText: typed });
}

function advanceDictation() {
  if (!session || session.paused || session.studyMode !== "dictation" || !session.dictationSubmitted) return;
  session.current = null;
  session.answerShown = false;
  session.dictationSubmitted = false;
  session.dictationResult = null;
  session.dictationInput = "";
  loadNextCard();
  if (session) saveState(true);
}

function showAnswer() {
  if (!session || !session.current || session.answerShown || session.studyMode === "dictation") return;
  session.answerShown = true;
  $("meaning-box").classList.remove("hidden");
  $("answer-buttons").classList.remove("hidden");
  $("reveal-button").classList.add("hidden");
  $("feedback-message").textContent = "做出判断：认识、模糊，还是不认识？";
  playFeedbackSound("reveal");
  registerActivity();
  saveState(true);
}

function updateDictationBook(item, correct) {
  const previousBook = item.book;
  item.dictationCount += 1;
  if (previousBook === "new") {
    item.book = correct ? "mastered" : "weak";
    item.dictationCorrectStreak = 0;
    item.dictationWrongStreak = 0;
    return correct ? "首测通过 · 已进入熟词本" : "首测未通过 · 已进入生词本";
  }
  if (previousBook === "weak") {
    item.dictationCorrectStreak = correct ? item.dictationCorrectStreak + 1 : 0;
    if (item.dictationCorrectStreak >= 10) {
      item.book = "mastered";
      item.dictationCorrectStreak = 0;
      item.dictationWrongStreak = 0;
      return "连对 10 次 · 晋级熟词本";
    }
    return correct ? `生词连续正确 ${item.dictationCorrectStreak} / 10` : "仍在生词本 · 连续正确已归零";
  }
  item.dictationWrongStreak = correct ? 0 : item.dictationWrongStreak + 1;
  if (item.dictationWrongStreak >= 2) {
    item.book = "weak";
    item.dictationCorrectStreak = 0;
    item.dictationWrongStreak = 0;
    return "连续错 2 次 · 回到生词本";
  }
  return correct ? "熟词保持 · 已通过" : "熟词连续错误 1 / 2";
}

function completeStandardRound(active, notify = true) {
  if (!active || active.kind === "reinforce" || active.finishedBase || !active.totalCount
    || !active.scopeWordIds.every((id) => active.baseSeen[id])) return false;
  active.finishedBase = true;
  const day = getDayStats();
  day.standardRounds += 1;
  state.reinforcementPool = {
    wordIds: [...new Set((active.weakIds || []).filter((wordId) => getWord(wordId)))],
    sourceRound: day.standardRounds,
    createdAt: new Date().toISOString(),
  };
  if (notify) showToast(`${bookLabel(active.scope)}完整覆盖 · +120 战力，重点词可在词表工具加练`);
  return true;
}

function answer(result, details = {}) {
  const isDictation = session?.studyMode === "dictation";
  if (!session || !session.current || (isDictation ? session.dictationSubmitted : !session.answerShown) || !["known", "fuzzy", "unknown"].includes(result)) return;
  registerActivity();
  clearTimeout(session.revealTimer);
  const id = session.current.id;
  const rollbackBefore = isDictation && details.deferNext && !details.replaying ? captureScoreSnapshot(id) : null;
  const item = getProgress(id);
  const elapsed = Math.max(0, performance.now() - session.cardStartedAt);
  item.lastResult = result;
  item.reviewCount += 1;
  item.lastReactionMs = Math.round(elapsed);
  item.lastReviewedAt = new Date().toISOString();
  const previousBook = item.book;
  session.bookFeedback = isDictation ? updateDictationBook(item, result === "known") : "";
  if (isDictation && details.replaying) applyDictationBookOverride(item);
  const bookTransition = isDictation && previousBook !== item.book;
  const day = getDayStats();
  day.shown += 1;
  day.recalls += 1;
  if (result === "known") {
    item.known += 1;
    item.familiarity = Math.min(100, item.familiarity + 4);
    day.known += 1;
  } else if (result === "fuzzy") {
    item.fuzzy += 1;
    item.familiarity = Math.min(100, item.familiarity + 1);
    day.fuzzy += 1;
  } else {
    item.unknown += 1;
    item.familiarity = Math.max(0, item.familiarity - 5);
    day.unknown += 1;
  }
  const baseXpGain = { known: 10, fuzzy: 5, unknown: 2 }[result] || 1;
  const doubleXpActive = state.shop.activeBoosts.doubleXpRemaining > 0;
  if (doubleXpActive) state.shop.activeBoosts.doubleXpRemaining -= 1;
  const xpGain = baseXpGain * (doubleXpActive ? 2 : 1);
  session.xp += xpGain;
  day.xp += xpGain;
  state.totalXp = (state.totalXp || 0) + xpGain;
  let stageXpGain = 0;
  if (result === "known") session.combo = (session.combo || 0) + 1;
  if (result === "fuzzy") {
    if (state.shop.activeBoosts.comboCharm > 0) state.shop.activeBoosts.comboCharm -= 1;
    else session.combo = 0;
  }
  if (result === "unknown") {
    if (state.shop.activeBoosts.unknownShield > 0) state.shop.activeBoosts.unknownShield -= 1;
    else session.combo = 0;
  }
  session.bestCombo = Math.max(session.bestCombo || 0, session.combo || 0);
  day.bestCombo = Math.max(day.bestCombo || 0, session.combo || 0);
  state.bestCombo = Math.max(state.bestCombo || 0, session.bestCombo || 0);
  session.streak = result === "known" ? (session.streak || 0) + 1 : 0;
  session.stageProgress = (session.stageProgress || 0) + 1;
  const stageComplete = session.stageProgress >= 20;
  if (stageComplete) {
    session.stageProgress = 0;
    session.stageReward = (session.stageReward || 0) + 25;
    session.xp += 25;
    day.xp += 25;
    day.stageCompletions = (day.stageCompletions || 0) + 1;
    state.totalXp += 25;
    stageXpGain = 25;
    if (state.shop.activeBoosts.stageBonusRemaining > 0) {
      state.shop.activeBoosts.stageBonusRemaining -= 1;
      session.xp += 100;
      day.xp += 100;
      state.totalXp += 100;
      stageXpGain += 100;
      showToast("阶段保险生效 · 额外 +100 XP");
    }
  }
  const isBaseSession = session.kind !== "reinforce";
  if (!session.baseSeen[id]) {
    session.baseSeen[id] = true;
    session.baseSeenCount = Object.keys(session.baseSeen).length;
  }
  if (isBaseSession && (result === "fuzzy" || result === "unknown")) {
    session.weakIds = [...new Set([...(session.weakIds || []), Number(id)])];
  }
  if (!isBaseSession) {
    session.reinforceSeenCount = (session.reinforceSeenCount || 0) + 1;
    session.extraCount = session.reinforceSeenCount;
    state.session.reinforceSeenCount = session.reinforceSeenCount;
    getDayStats().extras += 1;
  }
  completeStandardRound(session);
  let earnedPower = syncTrainingPower(day);
  [10, 25, 50].forEach((threshold) => {
    if (session.combo >= threshold && !state.milestones.comboRewards[threshold]) {
      const reward = { 10: 30, 25: 80, 50: 180 }[threshold];
      state.milestones.comboRewards[threshold] = true;
      earnedPower += awardPower(reward, `${threshold} 连击`, day);
      showToast(`${threshold} 连击达成 · +${reward} 战力`);
    }
  });
  applyFeedback(result, { xpGain: xpGain + stageXpGain, powerGain: earnedPower, stageComplete, doubleXpActive, bookTransition });
  if (details.deferNext) {
    session.answerShown = true;
    session.dictationSubmitted = true;
    session.dictationResult = result;
    session.dictationInput = typeof details.dictationText === "string" ? details.dictationText : "";
    syncAchievementRewards(true);
    if (rollbackBefore) {
      session.dictationRollback = { before: rollbackBefore, after: captureScoreSnapshot(id), originalResult: result };
      session.dictationOverridden = false;
    } else if (details.replaying && validDictationRollback(session.dictationRollback)) {
      session.dictationRollback.after = captureScoreSnapshot(id);
      session.dictationOverridden = result !== session.dictationRollback.originalResult;
    }
    saveState(true);
    updateHome();
    renderDictationSubmitted();
    return;
  }
  const answeredSession = session;
  session.current = null;
  session.answerShown = false;
  syncAchievementRewards(true);
  saveState(true);
  updateHome();
  clearTimeout(nextCardHandle);
  nextCardHandle = setTimeout(() => { if (session === answeredSession) loadNextCard(); }, 110);
}

function updateStreak() {
  const today = todayKey();
  if (state.lastStudyDate === today) return state.streak || 1;
  const previous = new Date();
  previous.setDate(previous.getDate() - 1);
  const previousKey = `${previous.getFullYear()}-${String(previous.getMonth() + 1).padStart(2, "0")}-${String(previous.getDate()).padStart(2, "0")}`;
  state.streak = state.lastStudyDate === previousKey ? (state.streak || 0) + 1 : 1;
  state.lastStudyDate = today;
  return state.streak;
}

function updateStudyMeta() {
  if (!session) return;
  const day = getDayStats();
  const isBaseSession = session.kind !== "reinforce";
  const seenCount = isBaseSession ? session.baseSeenCount : session.reinforceSeenCount;
  const totalCount = session.totalCount;
  const progress = totalCount ? Math.round((seenCount / totalCount) * 100) : 0;
  $("study-round-label").textContent = `${bookLabel(session.scope)} · ${studyModeLabel(session.studyMode)}`;
  $("study-progress-label").textContent = `${seenCount} / ${totalCount}`;
  $("study-progress-bar").style.width = `${progress}%`;
  $("study-micro-bar").style.width = `${getStagePercent()}%`;
  $("study-time-label").textContent = `本次 ${formatClock(session.activeMs)}`;
  $("study-active-time").textContent = formatClock(day.activeMs);
  $("study-streak-label").textContent = `连续 ${session.streak || 0}`;
  $("study-extra-label").textContent = isBaseSession ? `重点词 ${(session.weakIds || []).length}` : `本次加练 ${session.reinforceSeenCount || 0}`;
  $("study-power").textContent = state.powerBalance || 0;
  $("study-balance-label").textContent = `战力 ${state.powerBalance || 0}`;
  $("study-combo").textContent = `×${session.combo || 0}`;
  $("study-xp").textContent = day.xp || 0;
  $("study-stage-count").textContent = `${session.stageProgress || 0} / 20`;
  $("study-stage-label").textContent = session.stageProgress === 0 && session.stageReward ? "阶段完成" : "当前阶段";
  $("study-combo-chip").textContent = `连击 ×${session.combo || 0}`;
  if ($("study-order-toggle")) $("study-order-toggle").textContent = studyOrderLabel(session.orderMode);
  if (session.current) {
    const item = getProgress(session.current.id);
    $("study-book-status").textContent = `${bookLabel(item.book)} · ${wordBookStatus(item)}`;
    $("study-book-status").dataset.book = item.book;
  }
}

function applyFeedback(result, details = {}) {
  const card = $("word-card");
  card.classList.remove("flash-success", "flash-fuzzy", "flash-unknown");
  document.body.classList.remove("feedback-known", "feedback-fuzzy", "feedback-unknown");
  document.body.classList.add(`feedback-${result}`);
  const message = {
    known: session.combo >= 3 ? `认识！连击 ×${session.combo}` : "认识！继续保持节奏",
    fuzzy: "模糊词已标记，下一轮会优先",
    unknown: "已标记重点，下一轮会优先",
  }[result];
  $("feedback-message").textContent = message;
  $("impact-pop").textContent = `+${details.xpGain || 0} XP · +${details.powerGain || 0} 战力`;
  $("impact-pop").classList.remove("pop");
  void $("impact-pop").offsetWidth;
  $("impact-pop").classList.add("pop");
  $("study-combo-chip").classList.remove("hot");
  if (session.combo >= 3) {
    void $("study-combo-chip").offsetWidth;
    $("study-combo-chip").classList.add("hot");
  }
  if (state.settings.animation) {
    void card.offsetWidth;
    card.classList.add(`flash-${result}`);
  }
  playFeedbackSound(result, details.stageComplete || details.bookTransition);
  if (details.stageComplete) {
    showToast("阶段完成！获得技能点 +25 XP");
    $("feedback-message").textContent = "阶段完成！技能点已到账";
  }
}

function finishSession() {
  if (!session) return;
  clearInterval(timerHandle);
  clearTimeout(nextCardHandle);
  clearTimeout(session.revealTimer);
  const day = getDayStats();
  const lastResult = session;
  completeStandardRound(lastResult);
  syncTrainingPower(day);
  syncAchievementRewards(false);
  resultScope = lastResult.scope;
  const isReinforcementSession = lastResult?.kind === "reinforce";
  if (isReinforcementSession && lastResult.sourcePoolCreatedAt === state.reinforcementPool.createdAt) {
    state.reinforcementPool = { wordIds: [], sourceRound: 0, createdAt: null };
  }
  delete state.sessionsByScope[lastResult.scope];
  state.activeSessionScope = null;
  state.session = null;
  session = null;
  saveState(true);
  $("result-round").textContent = day.standardRounds;
  $("result-recalls").textContent = day.recalls;
  $("result-time").textContent = formatMinutes(day.activeMs);
  $("result-unknown").textContent = day.unknown;
  $("result-power").textContent = state.powerBalance || 0;
  $("result-level").textContent = `Lv.${getLevel(state.totalXp || 0)} · 最佳连击 ×${state.bestCombo || 0}`;
  $("result-reward-main").textContent = `+${lastResult?.xp || 0} XP · 今日战力 ${day.powerEarned || 0}`;
  $("result-reward-badge").textContent = day.checkin ? "今日打卡成功" : `${day.stageCompletions || 0} 个阶段完成`;
  $("result-title").textContent = isReinforcementSession ? "本轮重点加练完成" : lastResult.finishedBase ? `${bookLabel(resultScope)}已过完` : "本轮词条已清空";
  $("result-subtitle").textContent = isReinforcementSession
    ? "重点词已单独复习一遍，标准全量轮次不会被拖慢。"
    : lastResult?.finishedBase
      ? "本轮每词一次，下一轮按最新词本归属和熟识度排序。"
      : "没有有效词条的空轮不会计入标准轮，也不会发放整轮奖励。";
  const nextCount = getScopeWords(resultScope).length;
  $("next-round-button").disabled = !nextCount;
  $("next-round-button").textContent = nextCount ? `再练${bookLabel(resultScope)} · ${nextCount} 词` : `${bookLabel(resultScope)}暂无待练词`;
  showScreen("result");
  updateHome();
}

function pauseStudy() {
  if (!session) return;
  session.paused = !session.paused;
  session.lastTick = performance.now();
  session.lastActivity = performance.now();
  $("pause-study").textContent = session.paused ? "继续" : "暂停";
  $("word-card").style.opacity = session.paused ? "0.62" : "1";
  showToast(session.paused ? "已暂停，休息一下" : "继续训练");
  saveState(true);
}

function setStudyMode(mode) {
  if (!STUDY_MODES.includes(mode)) return;
  state.settings.studyMode = mode;
  saveState(true);
  updateHome();
  const activeMode = state.session && STUDY_MODES.includes(state.session.studyMode) ? state.session.studyMode : null;
  if (activeMode && activeMode !== mode) {
    showToast(`设置已保存；当前未完成轮仍按${studyModeLabel(activeMode)}续学`);
    return;
  }
  showToast(`下次训练将使用${studyModeLabel(mode)}`);
}

function updateSettings() {
  $("study-mode").value = STUDY_MODES.includes(state.settings.studyMode) ? state.settings.studyMode : "recall";
  $("reveal-seconds").value = String(state.settings.revealSeconds);
  $("goal-minutes").value = String(state.settings.goalMinutes);
  $("sound-enabled").checked = state.settings.sound;
  $("sound-volume").value = Math.round((state.settings.soundVolume ?? 1.6) * 100);
  $("animation-enabled").checked = state.settings.animation;
  document.body.dataset.theme = state.settings.theme || "aurora";
}

function exportData() {
  saveState(true);
  const payload = { exportedAt: new Date().toISOString(), wordsCount: words.length, state: JSON.parse(JSON.stringify(state)),
    reader: window.AppReader?.exportReadingData() };
  const json = JSON.stringify(payload, null, 2);
  const filename = `全量背词助手-学习数据-${todayKey()}.json`;
  const blob = new Blob([json], { type: "application/json;charset=utf-8" });
  fallbackExport(blob, json, filename, "学习数据已导出");
}

function fallbackExport(blob, json, filename, successMessage = "学习数据已导出") {
  try {
    if (navigator.share && typeof File === "function") {
      const file = new File([blob], filename, { type: "application/json" });
      if (!navigator.canShare || navigator.canShare({ files: [file] })) {
        navigator.share({ title: "全量背词助手学习数据", files: [file] })
          .then(() => showToast(successMessage))
          .catch((error) => {
            if (error?.name !== "AbortError") downloadBlob(blob, filename, json, successMessage);
          });
        return;
      }
    }
    downloadBlob(blob, filename, json, successMessage);
  } catch (error) {
    console.warn("导出文件失败", error);
    downloadBlob(blob, filename, json, successMessage);
  }
}

function downloadBlob(blob, filename, json, successMessage = "学习数据已导出") {
  try {
    if (typeof navigator.msSaveOrOpenBlob === "function") {
      navigator.msSaveOrOpenBlob(blob, filename);
      showToast(successMessage);
      return;
    }
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.rel = "noopener";
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    window.setTimeout(() => {
      link.remove();
      URL.revokeObjectURL(url);
    }, 1500);
    showToast(successMessage);
  } catch (error) {
    console.warn("浏览器下载失败，尝试复制数据", error);
    openBackupText(json);
  }
}

function openBackupText(json) {
  $("backup-text").value = json;
  $("backup-text-modal").classList.remove("hidden");
  showToast("当前容器未能下载文件，可复制备份文本");
}

async function copyBackupText() {
  const text = $("backup-text").value;
  try {
    if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
    else {
      $("backup-text").focus();
      $("backup-text").select();
      if (!document.execCommand("copy")) throw new Error("copy failed");
    }
    showToast("备份文本已复制");
  } catch (error) {
    showToast("复制失败，请长按文本框全选复制");
  }
}

function validateLearningBackup(payload) {
  const isRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  if (!isRecord(payload) || !isRecord(payload.state)) throw new Error("缺少学习状态");
  const saved = payload.state;
  if (!isRecord(saved.settings) || !isRecord(saved.progress)) throw new Error("学习设置或单词记录格式不正确");
  Object.values(saved.progress).forEach(validateBookProgress);
  if (saved.version != null && (!Number.isInteger(saved.version) || saved.version < 1 || saved.version > VERSION)) throw new Error("备份版本不受支持");
  if (saved.daily != null && (!isRecord(saved.daily) || Object.values(saved.daily).some((day) => !isRecord(day)))) throw new Error("每日学习记录格式不正确");
  if (saved.shop != null && !isRecord(saved.shop)) throw new Error("商店记录格式不正确");
  if (saved.achievements != null && !isRecord(saved.achievements)) throw new Error("成就记录格式不正确");
  if (saved.library != null) {
    if (!isRecord(saved.library) || !["builtin", "custom"].includes(saved.library.mode)) throw new Error("词库状态格式不正确");
    if (saved.library.builtinProgress != null) {
      if (!isRecord(saved.library.builtinProgress)) throw new Error("内置词表学习记录格式不正确");
      Object.values(saved.library.builtinProgress).forEach(validateBookProgress);
    }
    if (saved.library.customPackage != null) {
      const wordPackage = saved.library.customPackage;
      if (!isRecord(wordPackage) || wordPackage.type !== WORD_PACKAGE_TYPE || wordPackage.version !== WORD_PACKAGE_VERSION || !Array.isArray(wordPackage.words)) throw new Error("自定义词表格式不正确");
      if (wordPackage.words.length) validateWordPackage(wordPackage);
    }
    if (saved.library.mode === "custom" && !saved.library.customPackage) throw new Error("备份缺少自定义词表");
  }
  if (saved.session != null && (!isRecord(saved.session) || !Array.isArray(saved.session.queue))) throw new Error("未完成学习轮格式不正确");
  if (saved.sessionsByScope != null) {
    if (!isRecord(saved.sessionsByScope)) throw new Error("词本轮次记录格式不正确");
    Object.entries(saved.sessionsByScope).forEach(([scope, stored]) => {
      if (!SESSION_SCOPES.includes(scope) || !isRecord(stored) || !Array.isArray(stored.queue)
        || !Array.isArray(stored.scopeWordIds)) throw new Error("词本学习队列格式不正确");
      const ids = stored.scopeWordIds;
      if (ids.some((id) => !Number.isFinite(Number(id))) || new Set(ids.map(String)).size !== ids.length) throw new Error("词本快照包含无效或重复 ID");
      if (stored.queue.some((entry) => !isRecord(entry) || !Number.isFinite(Number(entry.id)))) throw new Error("词本队列包含无效 ID");
    });
  }
  if (saved.activeSessionScope != null && !SESSION_SCOPES.includes(saved.activeSessionScope)) throw new Error("当前词本标识不正确");
  return normalizeState(saved);
}

function importData(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const payload = JSON.parse(reader.result);
      const restored = validateLearningBackup(payload);
      clearTimeout(session?.revealTimer);
      clearTimeout(nextCardHandle);
      clearInterval(timerHandle);
      session = null;
      state = restored;
      if (payload.reader && typeof payload.reader === "object") window.AppReader?.restoreReadingData(payload.reader);
      if (state.library.mode === "custom" && Array.isArray(state.library.customPackage?.words)) activateCustomPackage(state.library.customPackage);
      else if (builtinWords.length) activateBuiltinWords();
      const recovery = recoverSavedDictationProgress();
      normalizeSavedSession();
      clearInterval(timerHandle);
      session = null;
      saveState(true);
      updateSettings();
      updateHome();
      renderAchievements();
      renderProfile();
      renderLibrary();
      showToast(recovery.repaired ? `学习数据已恢复，补回 ${recovery.repaired} 个漏记词` : "学习数据已恢复");
    } catch (error) {
      showToast(`导入失败：${error.message || "文件格式不正确"}`);
    }
    $("import-file").value = "";
  };
  reader.onerror = () => showToast("导入失败：无法读取文件");
  reader.readAsText(file);
}

function resetData() {
  if (!window.confirm("确定清空全部学习记录吗？词库不会被删除。")) return;
  clearTimeout(session?.revealTimer);
  clearTimeout(nextCardHandle);
  const activeLibrary = state.library?.mode === "custom" && state.library.customPackage?.words?.length
    ? { mode: "custom", builtinWordsetId: state.library?.builtinWordsetId || BUILTIN_WORDSET_ID, customPackage: makeWordPackage(words, {}), builtinProgress: { ...(state.library.builtinProgress || {}) } }
    : { mode: "builtin", builtinWordsetId: BUILTIN_WORDSET_ID, customPackage: state.library?.customPackage || null, builtinProgress: {} };
  state = defaultState();
  window.AppReader?.restoreReadingData(null);
  state.library = activeLibrary;
  state.progress = activeLibrary.mode === "custom"
    ? Object.fromEntries(words.map((word) => [word.id, normalizeProgressRecord({})]))
    : {};
  state.reinforcementPool = { wordIds: [], sourceRound: 0, createdAt: null };
  session = null;
  clearInterval(timerHandle);
  saveState(true);
  updateSettings();
  updateHome();
  renderLibrary();
  $("settings-modal").classList.add("hidden");
  showScreen("home");
  showToast("学习记录已清空");
}

async function loadWords() {
  if (Array.isArray(window.WORDS_INLINE) && window.WORDS_INLINE.length) {
    builtinWords = normalizeWordList(window.WORDS_INLINE);
    loadActiveWordList();
    return;
  }
  console.error(new Error("words-inline.js 未提供有效词库"));
  $("library-pill").textContent = "词库读取失败";
  $("book-training-hint").textContent = "请确认 words-inline.js 存在";
  showToast("词库读取失败，请确认 words-inline.js 存在");
}

function loadActiveWordList() {
  if (state.library.mode === "custom" && Array.isArray(state.library.customPackage?.words)) activateCustomPackage(state.library.customPackage);
  else activateBuiltinWords();
  const recovery = recoverSavedDictationProgress();
  normalizeSavedSession();
  libraryLoaded = true;
  saveState(true);
  $("library-pill").textContent = `${words.length} 个词 · ${state.library.mode === "custom" ? "自定义词表" : "内置词库"}`;
  updateHome();
  renderLibrary();
  if (recovery.repaired) showToast(`已补回 ${recovery.repaired} 个漏记词：熟词 ${recovery.known}，生词 ${recovery.unknown}`);
}

function bindEvents() {
  $("open-reader").addEventListener("click", () => {
    if (session) suspendStudy();
    showScreen("reader");
  });
  $("reader-back").addEventListener("click", () => {
    showScreen("home");
    $("open-reader").focus({ preventScroll: true });
  });
  document.querySelectorAll(".nav-item").forEach((item) => item.addEventListener("click", () => {
    const target = item.dataset.screen;
    if (target === "study") {
      resumeLastSession();
      return;
    }
    if (session && target !== "study") {
      suspendStudy();
    }
    showScreen(target);
  }));
  document.querySelectorAll(".theme-option").forEach((button) => button.addEventListener("click", () => setTheme(button.dataset.theme)));
  document.querySelectorAll(".achievement-tab").forEach((button) => button.addEventListener("click", () => switchAchievementPanel(button.dataset.panel)));
  $("calendar-prev").addEventListener("click", () => { calendarMonth -= 1; if (calendarMonth < 0) { calendarMonth = 11; calendarYear -= 1; } renderCalendarMonth(); });
  $("calendar-next").addEventListener("click", () => { calendarMonth += 1; if (calendarMonth > 11) { calendarMonth = 0; calendarYear += 1; } renderCalendarMonth(); });
  $("calendar-today").addEventListener("click", () => { calendarYear = new Date().getFullYear(); calendarMonth = new Date().getMonth(); renderCalendarMonth(); });
  document.querySelectorAll("[data-study-scope]").forEach((button) => {
    button.addEventListener("click", () => startSession(true, button.dataset.studyScope));
  });
  $("reinforce-button").addEventListener("click", startReinforcementSession);
  $("legacy-session-button").addEventListener("click", () => startSession(true, "legacy"));
  $("next-round-button").addEventListener("click", () => startSession(false, resultScope));
  $("back-home-button").addEventListener("click", () => { updateHome(); showScreen("home"); });
  $("reveal-button").addEventListener("click", showAnswer);
  $("dictation-submit").addEventListener("click", submitDictation);
  $("dictation-override").addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    toggleDictationVerdict();
  });
  $("dictation-box").addEventListener("keydown", (event) => {
    if (event.key !== "Enter" || event.isComposing || event.keyCode === 229 || event.ctrlKey || event.metaKey || event.altKey) return;
    event.preventDefault();
    event.stopPropagation();
    if (!event.repeat) submitDictation();
  });
  $("dictation-input").addEventListener("input", (event) => {
    if (!session || session.studyMode !== "dictation" || session.dictationSubmitted) return;
    session.dictationInput = event.target.value;
    registerActivity();
    saveState();
  });
  document.querySelectorAll(".answer-button").forEach((button) => button.addEventListener("click", () => answer(button.dataset.result)));
  $("exit-study").addEventListener("click", () => {
    suspendStudy();
    updateHome();
    showScreen("home");
  });
  $("pause-study").addEventListener("click", pauseStudy);
  $("study-order-toggle").addEventListener("click", toggleStudyOrder);
  $("open-settings").addEventListener("click", () => { updateSettings(); $("settings-modal").classList.remove("hidden"); });
  $("close-settings").addEventListener("click", () => $("settings-modal").classList.add("hidden"));
  $("settings-modal").addEventListener("click", (event) => { if (event.target === $("settings-modal")) $("settings-modal").classList.add("hidden"); });
  $("close-backup-text").addEventListener("click", () => $("backup-text-modal").classList.add("hidden"));
  $("backup-text-modal").addEventListener("click", (event) => { if (event.target === $("backup-text-modal")) $("backup-text-modal").classList.add("hidden"); });
  $("copy-backup-text").addEventListener("click", copyBackupText);
  $("close-word-edit").addEventListener("click", closeWordEditor);
  $("cancel-word-edit").addEventListener("click", closeWordEditor);
  $("save-word-edit").addEventListener("click", saveWordEdits);
  $("word-edit-modal").addEventListener("click", (event) => { if (event.target === $("word-edit-modal")) closeWordEditor(); });
  $("word-edit-meaning").addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
      event.preventDefault();
      saveWordEdits();
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !$("word-edit-modal").classList.contains("hidden")) closeWordEditor();
  });
  $("study-mode").addEventListener("change", (event) => setStudyMode(event.target.value));
  $("reveal-seconds").addEventListener("change", (event) => { state.settings.revealSeconds = Number(event.target.value); saveState(true); });
  $("goal-minutes").addEventListener("change", (event) => { state.settings.goalMinutes = Number(event.target.value); saveState(true); updateHome(); });
  $("sound-enabled").addEventListener("change", (event) => { state.settings.sound = event.target.checked; saveState(true); });
  $("sound-volume").addEventListener("input", (event) => { state.settings.soundVolume = Number(event.target.value) / 100; saveState(); });
  $("animation-enabled").addEventListener("change", (event) => { state.settings.animation = event.target.checked; saveState(true); });
  $("shop-grid").addEventListener("click", (event) => { const button = event.target.closest("[data-shop-action]"); if (button) purchaseShopItem(button.dataset.shopId); });
  $("export-button").addEventListener("click", exportData);
  $("import-button").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", (event) => { if (event.target.files[0]) importData(event.target.files[0]); });
  $("reset-button").addEventListener("click", resetData);
  $("word-search").addEventListener("input", (event) => { librarySearch = event.target.value; const scroll = $("word-list-scroll"); if (scroll) scroll.scrollTop = 0; renderLibrary(); });
  $("familiarity-filter").addEventListener("change", (event) => { libraryFamiliarityFilter = event.target.value; const scroll = $("word-list-scroll"); if (scroll) scroll.scrollTop = 0; renderLibrary(); });
  document.querySelectorAll("[data-library-book]").forEach((button) => {
    button.addEventListener("click", () => {
      libraryBookFilter = button.dataset.libraryBook;
      selectedWordIds.clear();
      $("word-list-scroll").scrollTop = 0;
      renderLibrary();
    });
  });
  $("word-list-scroll").addEventListener("scroll", () => {
    syncLibraryRail();
    cancelAnimationFrame(libraryRenderFrame);
    libraryRenderFrame = requestAnimationFrame(renderLibraryList);
  }, { passive: true });
  $("word-list-content").addEventListener("click", handleLibraryListClick);
  $("word-list-content").addEventListener("change", handleLibraryListChange);
  $("select-visible-words").addEventListener("change", selectVisibleLibraryWords);
  $("delete-selected-words").addEventListener("click", () => {
    const ids = [...selectedWordIds];
    if (ids.length && window.confirm(`确定删除选中的 ${ids.length} 个词吗？对应熟识度记录也会一起删除。${libraryMutationNotice()}`)) removeWordIds(ids, true);
  });
  $("word-export-button").addEventListener("click", exportWordList);
  $("word-import-button").addEventListener("click", () => $("word-import-file").click());
  $("word-import-file").addEventListener("change", (event) => { if (event.target.files[0]) importWordList(event.target.files[0]); });
  $("restore-builtin-button").addEventListener("click", restoreBuiltinWords);
  $("restore-custom-button").addEventListener("click", restoreCustomWords);
  $("word-list-top").addEventListener("click", () => { $("word-list-scroll").scrollTo({ top: 0, behavior: "smooth" }); });
  $("word-list-bottom").addEventListener("click", () => { const scroll = $("word-list-scroll"); scroll.scrollTo({ top: scroll.scrollHeight, behavior: "smooth" }); });
  $("word-list-thumb").addEventListener("pointerdown", (event) => {
    libraryThumbDragging = true;
    event.currentTarget.setPointerCapture?.(event.pointerId);
    event.preventDefault();
  });
  $("word-list-thumb").addEventListener("pointermove", (event) => {
    if (!libraryThumbDragging) return;
    const track = $("word-list-track");
    const thumb = $("word-list-thumb");
    const rect = track.getBoundingClientRect();
    const ratio = (event.clientY - rect.top - thumb.offsetHeight / 2) / Math.max(1, rect.height - thumb.offsetHeight);
    setLibraryScrollRatio(ratio);
  });
  $("word-list-thumb").addEventListener("pointerup", () => { libraryThumbDragging = false; });
  $("word-list-thumb").addEventListener("pointercancel", () => { libraryThumbDragging = false; });
  $("word-list-track").addEventListener("pointerdown", (event) => {
    if (event.target === $("word-list-thumb")) return;
    const rect = event.currentTarget.getBoundingClientRect();
    setLibraryScrollRatio((event.clientY - rect.top) / rect.height);
  });
  document.addEventListener("visibilitychange", () => { if (document.hidden) saveState(true); if (session) session.lastTick = performance.now(); });
  window.addEventListener("beforeunload", () => saveState(true));
  document.addEventListener("click", registerActivity);
}

bindEvents();
updateSettings();
updateHome();
loadWords();
