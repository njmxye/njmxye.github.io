(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.ProgressRecovery = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  function recover(state, activeWordIds, recoveredAt = new Date().toISOString()) {
    const result = { repaired: 0, known: 0, unknown: 0, records: [] };
    const saved = state.sessionsByScope?.new || (state.session?.scope === "new" ? state.session : null);
    if (!saved || saved.scope !== "new" || saved.studyMode !== "dictation" || saved.kind === "reinforce"
      || !saved.baseSeen || !Array.isArray(saved.scopeWordIds) || !Array.isArray(saved.weakIds)
      || !Array.isArray(saved.queue) || !state.progress) return result;

    const seen = Object.keys(saved.baseSeen).filter((id) => saved.baseSeen[id]);
    if (saved.baseSeenCount !== seen.length) return result;
    const active = new Set(activeWordIds.map(String));
    const scope = new Set(saved.scopeWordIds.map(String));
    const wrong = new Set(saved.weakIds.map(String));
    const queued = new Set(saved.queue.map((entry) => String(entry.id)));
    const currentId = saved.current ? String(saved.current.id) : null;

    seen.forEach((id) => {
      const item = state.progress[id];
      // Only a first-test round with an untouched word has enough evidence.
      // Never infer outcomes for recall, later reviews, or contradictory queues.
      if (!active.has(id) || !scope.has(id) || queued.has(id)
        || (id === currentId && !saved.dictationSubmitted)
        || !item || item.book !== "new" || item.lastResult != null || item.lastReviewedAt != null
        || ["known", "fuzzy", "unknown", "reviewCount", "dictationCount", "dictationCorrectStreak", "dictationWrongStreak", "familiarity"]
          .some((field) => Number(item[field] || 0) !== 0)) return;

      const verdict = wrong.has(id) ? "unknown" : "known";
      if (id === currentId && saved.dictationResult !== verdict) return;
      const repaired = {
        ...item,
        familiarity: verdict === "known" ? 4 : 0,
        lastResult: verdict,
        known: verdict === "known" ? 1 : 0,
        fuzzy: 0,
        unknown: verdict === "unknown" ? 1 : 0,
        reviewCount: 1,
        // Original answer timestamps/reaction times were not retained.
        lastReactionMs: 0,
        lastReviewedAt: null,
        book: verdict === "known" ? "mastered" : "weak",
        dictationCount: 1,
        dictationCorrectStreak: 0,
        dictationWrongStreak: 0,
      };
      state.progress[id] = repaired;
      result.records.push({ id: Number(id), result: verdict, book: repaired.book });
      result.repaired += 1;
      result[verdict] += 1;
      // A result screen saved by the faulty build can still be overridden.
      const rollback = saved.dictationRollback;
      if (id === currentId && rollback?.after && String(rollback.after.id) === id) {
        rollback.after.item = { ...repaired };
      }
    });

    if (result.repaired) {
      const previous = state.progressRecovery || {};
      const records = { ...(previous.records || {}) };
      result.records.forEach((record) => {
        records[record.id] = { ...record, recoveredAt, source: "new-dictation-session", originalTimingUnavailable: true };
      });
      state.progressRecovery = { version: 1, lastRecoveredAt: recoveredAt, records };
      // Keep the active package synchronized, including for backup imports.
      if (state.library?.mode === "custom" && Array.isArray(state.library.customPackage?.words)) {
        const repairedIds = new Set(result.records.map((record) => String(record.id)));
        state.library.customPackage.words.forEach((word) => {
          if (repairedIds.has(String(word.id))) word.progress = { ...state.progress[word.id] };
        });
      } else if (state.library?.mode === "builtin") {
        state.library.builtinProgress = { ...state.progress };
      }
    }
    return result;
  }

  return { recover };
});
